package se.spraakbanken.bwsannotation;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.StringJoiner;
import java.util.TreeMap;
import java.util.function.BiConsumer;
import java.util.function.BiPredicate;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.rouces.jac.jutils.Java2Python;
import org.rouces.jac.jutils.textfiles.TextFileReaderBR;

import se.spraakbanken.saldo.Lemgram;
import se.spraakbanken.saldo.SaldoWordSense;



/**
 * Takes $annotationSetDs annotated and outputs html code
 * @author Jacobo Rouces <jacobo@rouces.org>
 *
 */
public class BWSAnnotationFormCreator {
	

	/** Word senses that will be part of the gs */
	static public List<SaldoWordSense> wsGs = new LinkedList<>();
	/** Main representative lemgram for each gs */
	static public Map<SaldoWordSense,Lemgram> wsGs2lg = new HashMap<>();
	static public String descriptorFileStr = "...";

	
	static MultilingualGuiLabels l = new MultilingualGuiLabels(MultilingualGuiLabels.SWEDISH);
	
	public static void main(String[] args) {
		
		// Run this to get the main html
		usingMaxdiff();
		// Run this to get the group list html (the left progress column in the GUI). You have to edit the number manually.
		createGroupList(556);
	}
	
	/**
	 * Attention: the algorithm can enter infinite loop in some runs. Not worth fixing since this is a one run experiment.
	 */
	public static void usingMaxdiff() {
		
//		Given n terms to be annotated, the first step is
//		to randomly sample this set (with replacement) to
//		obtain sets of four terms each, 4-tuples, that satisfy
//		the following criteria:
//		1. no two 4-tuples have the same four terms: 						combinations
//		2. no two terms within a 4-tuple are identical: 					without repetition
//		3. each term in the term list appears approximately 				
//			in the same number of 4-tuples;
//		4. each pair of terms appears approximately in 						
//			the same number of 4-tuples.
		
		
		Map<String,String> wsid2decriptors = loadDescritors(descriptorFileStr);
		
		// {{ Build html and maxdiff 

		int numberOfElementsInGs = wsGs.size();
		int maxDiffFactor = 2;
		int totalNumberOfTuples = numberOfElementsInGs*maxDiffFactor; //278*2=556, but for a small bug below we produce 572
		int tupleSize = 4;
		
		//System.err.println(totalNumberOfTuples);
		
		System.out.println("");
		StringBuffer sb = new StringBuffer();
		
		sb.append("<div id='groups-auto'>\n\n\n");


//		// List of saldo ids in the GS
//		sb.append("<!-- List of saldo ids in the GS, for anyone needing them \n");
//		for (SaldoWordSense ws : DirectAnnotationReader.wsGs) {
//			sb.append(ws+" , ");
//		}
//		sb.append("-->\n\n\n");
		
		
		// Logic to keep pair of pairs of elements already used
		Set<String> pairsAlreadyUsed = new HashSet<String>(); 
		BiConsumer<SaldoWordSense,SaldoWordSense> addToPairsAlreadyUsed = (i, j) -> {
			pairsAlreadyUsed.add(i.getId()+"%%%%"+j.getId());
			pairsAlreadyUsed.add(j.getId()+"%%%%"+i.getId());
		};
		BiPredicate<SaldoWordSense,SaldoWordSense> checkIfPairsAlreadyUsed = (i, j) -> {
			return pairsAlreadyUsed.contains(i.getId()+"%%%%"+j.getId());
		};
		
		Map<String,Integer> numberOfTimesSwsAppears = new HashMap<>();
		for (SaldoWordSense sws : wsGs) {
			numberOfTimesSwsAppears.put(sws.getId(), 0);
		}
		
		List<SaldoWordSense> wsGsQueue = new LinkedList<SaldoWordSense>();
		int tuplesCreated = 0;
		// While we have not created all tuples yet
		while (tuplesCreated<totalNumberOfTuples) {
			
			// We prepare a new round across the elements of the GS
			List<SaldoWordSense> wsGsTemp = new LinkedList<SaldoWordSense>(wsGs);
			Collections.shuffle(wsGsTemp, new Random(0));
			wsGsQueue.addAll(wsGsTemp);
			int antiFreezeCounter = 0;
			
			// While there are still elements for this round
			loopEmptyingQueue: while (wsGsQueue.size()>=4) {
				
				List<SaldoWordSense> currentTuple = new LinkedList<SaldoWordSense>();

				loopFillingTuple: for (int tupleArgIdx = 0; tupleArgIdx<tupleSize; ) {
					SaldoWordSense nextElement = wsGsQueue.remove(0);
					// Check if the new element creates a pair with some element in the current tuple 
					// that already exists in another tuple
					for (SaldoWordSense elementAlreadyInCurrentTuple : currentTuple) {
						if (checkIfPairsAlreadyUsed.test(nextElement, elementAlreadyInCurrentTuple)) {
							// If we reach this, the answer is yes
							// First check if we have done this many times and we are stuck in a loop
							if (antiFreezeCounter++>wsGsTemp.size()) {
								break loopEmptyingQueue;
							}
							// Add this element to the end
							// And try next
							wsGsQueue.add(nextElement);
							//System.err.println("Pair exists");
							continue loopFillingTuple;
						}
					}
					// If we reach this, the answer is no
					// So we can use the element to add it to the tuple
					currentTuple.add(nextElement);
					tupleArgIdx++;
					for (SaldoWordSense elementAlreadyInCurrentTuple : currentTuple) {
						addToPairsAlreadyUsed.accept(nextElement, elementAlreadyInCurrentTuple);
					}

				}
				
				//System.out.println(currentTuple);

				sb.append(
					"\t<table class='group-table' id='group-table-"+tuplesCreated+"'><tr><td>\n" + //"+((tuplesCreated==0)?"":" blocked")+"
					"\t\n" +
					"\t<b>Group "+(tuplesCreated+1)+"</b>\n" +
					"\t\n" +
					"\t</td><td>\n" +
					"\t\n" +
					"\t<table class='group-table-known'>\n"+
					"\t<tr>\n"+
					"\t<td class='upperrow'>"+l._most_negative()+"</td>\n"+
					"\t<td class='upperrow' width='100px'><div>"+l._word()+"</div></td>\n"+
					"\t<td class='upperrow' width='100px'><div>"+l._type()+"</div></td>\n"+
					"\t<td class='upperrow' width='300px'><div>"+l._associated_words()+"</div></td>\n"+
					"\t<td class='upperrow'>"+l._most_positive()+"</td>\n"+
					"\t</tr>\n");
				//for (int i = 0; i < currentTuple.size(); i++) {
					//Integer index = currentTuple.get(i);
				for (SaldoWordSense saldoWordSense : currentTuple) {
					
					numberOfTimesSwsAppears.put(saldoWordSense.getId(), numberOfTimesSwsAppears.get(saldoWordSense.getId())+1);
					
//					StringJoiner disambiguationWordsJoiner = new StringJoiner(", ");
//					//disambiguationWordsJoiner.add("");disambiguationWordsJoiner.add("");disambiguationWordsJoiner.add("");disambiguationWordsJoiner.add("");
//					//if (saldo.senseString2ws.get(saldoWordSense.getSenseString()).size()>1) {
//						//System.err.println(word2wordSenses.get(sws.getLemma()).size());
//						//System.out.println(ws.toString()+"  -  "+ws.getPrimaryDescriptor());
//						for (int j = 0; j < Math.min(saldoWordSense.getSecondaryDescriptors().size(), 4); j++) {
//							disambiguationWordsJoiner.add(
//									saldoWordSense.getSecondaryDescriptors().get(j).lemgrams.stream().
//								    map(Lemgram::getLemma).
//								    filter(s -> s != null && !s.isEmpty()).
//								    collect(Collectors.joining(", ")).toString());
//						}
//						if (saldoWordSense.getSecondaryDescriptors().size()==0) {
//							disambiguationWordsJoiner.add(
//									saldoWordSense.getPrimaryDescriptor().lemgrams.stream().
//								    map(Lemgram::getLemma).
//								    filter(s -> s != null && !s.isEmpty()).
//								    collect(Collectors.joining(", ")).toString());
//							disambiguationWordsJoiner.add(
//									saldoWordSense.getPrimaryDescriptor().getPrimaryDescriptor().lemgrams.stream().
//								    map(Lemgram::getLemma).
//								    filter(s -> s != null && !s.isEmpty()).
//								    collect(Collectors.joining(", ")).toString());
//						}
					//}
					
					sb.append(
							"\t<tr>\n"+
							"\t<td " +
								"class='negative-selector "+saldoWordSense+" group-negatives-"+tuplesCreated+"' " +
								"id='group-"+tuplesCreated+"-contains-negative-"+saldoWordSense+"' " +
								"onclick='swapSelection(\"group-"+tuplesCreated+"-contains-negative-"+saldoWordSense+"\")'></td>\n"+
							//"\t<td width='100px'><div>"+lemgramCList+"</div></td>\n"+
							//"\t<td width='100px'><div>"+posCList+"</div></td>\n"+
							"\t<td width='100px'><div>"+wsGs2lg.get(saldoWordSense).lemma+"</div></td>\n"+
							"\t<td width='100px'><div>"+wsGs2lg.get(saldoWordSense).getPosInLaySwedish()+"</div></td>\n"+
							//"\t<td width='300px'><div>"+disambiguationWordsJoiner.toString()+"</div></td>\n"+
							"\t<td width='300px'><div>"+wsid2decriptors.get(saldoWordSense.getId())+"</div></td>\n"+
							"\t<td " +
								"class='positive-selector "+saldoWordSense+" group-positives-"+tuplesCreated+"' " +
								"id='group-"+tuplesCreated+"-contains-positive-"+saldoWordSense+"' " +
								"onclick='swapSelection(\"group-"+tuplesCreated+"-contains-positive-"+saldoWordSense+"\")'></td>\n"+
							"\t</tr>\n");
				}

				
				sb.append(
					"\t</table>\n" +
					"\t\n" +
					"\t</td><td>\n" +
					"\t\n" +
					"\t<table class='group-table-unknown'>\n" +
					"\t<tr>\n" +
					"\t<td class='upperrow'>"+l._I_am_not_sure()+"</td>\n" +
					"\t</tr>\n" +
					"\t<tr>\n" +
					"\t<td class='unknown-selector' id='group-"+tuplesCreated+"-unknown' onclick='swapSelection(\"group-"+tuplesCreated+"-unknown\")'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>\n" +
					"\t</tr>\n" +
					"\t</table>\n" +
					"\t</td></tr></table>\n" +
					"\t\n"+
					"\t<br><br><br>\n" +
					"\t\n"
				);
				
				tuplesCreated++;
			}
		}
		
		//System.out.println(pairsAlreadyUsed);

		sb.append("\t</div> <!--end groups-auto-->\n\n");
		
		System.out.println(sb.toString());
		
		System.out.println("\n\n\ttimes_sws_in_tuple="+Java2Python.map2dictionary(numberOfTimesSwsAppears));

		// }}
		
	}


	
	
	
	
//	public static void usingScale() {
//		
//		List<SaldoWordSense> wsIds = new LinkedList<SaldoWordSense>(saldo.id2ws.values());
//		
//		//Collections.shuffle(wsIds);
//
//		int numberOfElementsInGs = 200;
//		Set<SaldoWordSense> wsGsIds = new HashSet<SaldoWordSense>();
//		for (int i = 0; wsGsIds.size()<=numberOfElementsInGs; i++ ) {
//			SaldoWordSense ws = wsIds.get(i);
//			if (senSaldoFilter.isSentimentalCandidate(ws)) {
//				wsGsIds.add(ws);
//			}
//		}
//		
//		// Print html
//		StringBuffer sb = new StringBuffer();
//		for (SaldoWordSense ws : wsGsIds) {
//			//System.out.println(sws.toString());
//			
//			StringBuilder secondaries = new StringBuilder();
//			if (saldo.senseString2ws.get(ws.getSenseString()).size()>1) {
//				//System.err.println(word2wordSenses.get(sws.getLemma()).size());
//				System.out.println(ws.toString()+"  -  "+ws.getPrimaryDescriptor());
//				secondaries.append(ws.getPrimaryDescriptor().getSenseString()+" ");
//				for (int j = 0; j < Math.min(ws.getSecondaryDescriptors().size(), 4); j++) {
//					secondaries.append(ws.getSecondaryDescriptors().get(j).getSenseString()+" ");
//				}
//			}
//			
//			sb.append(
//					"<tr>"+
//					"	<td><div>"+ws.getSenseString().replace('_', ' ')+"</div></td>"+
//					"	<td><div>"+secondaries.toString()+"</div></td>"+
//					"	<th colspan='5' class='slider'>" +
//					"		<div>" +
//					"			<input type='range' min='-2' max='2' value='0' step='1' onchange='updateValue(this.value)'/> " +
//					"		</div></th>"+
//					"</tr>" +
//					"\n\n");
//						
//		}
//		System.out.println(sb.toString());
//		
//	}
	
	


	
	
	public static void createGroupList(int numberOfGroups) {
		StringBuffer sb = new StringBuffer();
		sb.append(
				"\t<div id='group-menu-scroll-auto'>\n"+
				"\t\t<ul id='group-menu'>\n");
		for (int i = 0; i < numberOfGroups; i++) {
			sb.append("\t\t\t<li id='group-table-"+i+"-link' onclick='moveFocusToGroup($(\"#group-table-"+i+"\"))'>"+(i+1)+"</li>\n");
		}
		sb.append(
				"\t\t</ul>\n"+
				"\t</div><!--end group-list-auto-->\n");
		System.out.println(sb.toString());
	}
	
	
	public static Map<String,String> loadDescritors(String fileStr) {
		
		Map<String,String> map = new HashMap<>();
		
		TextFileReaderBR reader = new TextFileReaderBR(fileStr);
		String line = reader.readLine();
		int linesRead = 0;
		while((line = reader.readLine())!=null) {
			linesRead++;
			if (line.startsWith("#")||line.isEmpty()) {
				line = reader.readLine();
				continue;
			}
			// Using split
			String[] elements = line.split("\\t");
			String el0 = elements[0];
			String el2 = elements[2];
			//System.out.println(el0+" / "+el2);
			map.put(el0, el2);

		}
		//System.out.println("linesRead="+linesRead);
		return map;
	}
	
	public static void deprecatedGsElementSelection() {
//		//// Random picking
//		List<SaldoWordSense> wsIds = new LinkedList<SaldoWordSense>(saldo.id2ws.values());
//		Collections.shuffle(wsIds);
//		List<SaldoWordSense> wsGs = new LinkedList<SaldoWordSense>();
//		// wsGsIdxs contains integer indices for wsGs, the shuffling will be done to wsGsIdxs
//		for (int i = 0; wsGsIdxs.size()<=numberOfElementsInGs; i++ ) {
//			SaldoWordSense ws = wsIds.get(i);
//			if (SenSaldo.isSentimentalCandidate(ws)) {
//				wsGs.add(ws);
//			} else {
//				//System.err.println("filtered out: "+ws.getId());
//			}
//		}
//		// Dummy
//		//for (int i = 0; wsGsIdxs.size()<=numberOfElementsInGs; i++ ) wsGsIdxs.add(i);
		
		
		//// From MicroWnOp
//		List<SaldoWordSense> wsGsFromOutside = new LinkedList<SaldoWordSense>();
//		//List<Integer> wsGsIdxs = new LinkedList<Integer>();
//		// wsGsIdxs contains integer indices for wsGs, the shuffling will be done to wsGsIdxs
//		MicroWnOpReader microWnOp = new MicroWnOpReader();
//		microWnOp.load();
//		Lemma2LemmaDictionary swe2engDict = LexinReader.loadLemma2LemmaDictionary(
//				Directories.getDataDir(null)+
//				"lexin svensk dictionary/XML_Engelska080601");
//		Lemma2LemmaDictionary eng2sweDict = swe2engDict.getReverse();
//		microWnOp.words.forEach((String engWord) -> {
//			for (String sweWord : eng2sweDict.getTranslations(engWord)) {
//				if (saldo.lemma2ws.get(sweWord)!=null) for (SaldoWordSense ws : saldo.lemma2ws.get(sweWord)) {
//					if (senSaldoFilter.isSentimentalCandidate(ws)&&ws.getSenseNumber()==1) {
//						//System.out.println(ws);
//						wsGsFromOutside.add(ws);
//					}
//				}
//			}
//		});
//		List<SaldoWordSense> wsGs = wsGsFromOutside.subList(0, numberOfElementsInGs-1);
	}
	
}
