package se.spraakbanken.bwsannotation;

import java.util.Locale;

import javax.management.RuntimeErrorException;

/**
 * Multilingual GUI labels.
 * 
 * @author Jacobo Rouces <jacobo@rouces.org>
 *
 */
public class MultilingualGuiLabels {

	public static final Locale ENGLISH = new Locale("eng");
	public static final Locale SWEDISH = new Locale("swe");
	
	Locale lang;
	
	public MultilingualGuiLabels(Locale lang) {
		this.lang = lang;
	}
	
	public String _most_positive(){
		if (lang==ENGLISH) {
			return "most positive";
		} else if (lang==SWEDISH) {
			return "mest positivt";
		} else throw new RuntimeException("Language not supported: "+lang);
	}
	
	public String _most_negative(){
		if (lang==ENGLISH) {
			return "most negative";
		} else if (lang==SWEDISH) {
			return "mest negativt";
		} else throw new RuntimeException("Language not supported: "+lang);
	}
	
	public String _word(){
		if (lang==ENGLISH) {
			return "word";
		} else if (lang==SWEDISH) {
			return "ord";
		} else throw new RuntimeException("Language not supported: "+lang);
	}
	
	public String _type(){
		if (lang==ENGLISH) {
			return "type";
		} else if (lang==SWEDISH) {
			return "ordklass";
		} else throw new RuntimeException("Language not supported: "+lang);
	}
	
	public String _associated_words(){
		if (lang==ENGLISH) {
			return "associated words";
		} else if (lang==SWEDISH) {
			return "associerade ord";
		} else throw new RuntimeException("Language not supported: "+lang);
	}
	
	public String _I_am_not_sure(){
		if (lang==ENGLISH) {
			return "I am not sure";
		} else if (lang==SWEDISH) {
			return "vet ej/osäker";
		} else throw new RuntimeException("Language not supported: "+lang);
	}
	
	public String _(){
		if (lang==ENGLISH) {
			return "";
		} else if (lang==SWEDISH) {
			return "";
		} else throw new RuntimeException("Language not supported: "+lang);
	}
	
	
	/*
	public String _(){
		if (lang==ENGLISH) {
			return "";
		} else if (lang==SWEDISH) {
			return "";
		} else throw new RuntimeException("Language not supported: "+lang);
	}
	*/

}
