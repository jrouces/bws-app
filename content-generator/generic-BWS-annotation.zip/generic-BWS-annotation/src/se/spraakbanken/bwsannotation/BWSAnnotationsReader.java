package se.spraakbanken.bwsannotation;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.rouces.jac.jutils.Java2Python;
import org.rouces.jac.jutils.textfiles.TextFileReaderBR;

//import org.rouces.jac.jutils.Directories;
//import org.rouces.jac.jutils.Java2Python;
//import org.rouces.jac.jutils.textfiles.TextFileReaderBR;
//import org.rouces.jacobo.spraakbanken.sensaldo.PNOSentiment;

public class BWSAnnotationsReader {

	public static void main(String[] args) {
		Map<String,PNOSentiment> bwsAnnotation1 = load("...");
		System.out.println("bws_annotation_map_1="+Java2Python.map2dictionary(bwsAnnotation1));
		Map<String,PNOSentiment> bwsAnnotation2 = load("...");
		System.out.println("bws_annotation_map_2="+Java2Python.map2dictionary(bwsAnnotation2));

	}
	
	public static Map<String,PNOSentiment> load(String fileStr) {
		
		//group-210-contains-positive-prisbelöna..1
		//group-210-contains-negative-skyldig..1
		//group-211-unknown
		
		Map<String,PNOSentiment> map = new HashMap<>();
		 
		Path file = Paths.get(fileStr);
		
		TextFileReaderBR reader = new TextFileReaderBR(file.toString());
		String line = reader.readLine();
		int linesRead = 0;
		while((line = reader.readLine())!=null) {
			linesRead++;
			if (line.startsWith("#")||line.isEmpty()) {
				line = reader.readLine();
				continue;
			}
			// Using split
			String[] elements = line.split("-");
			if (!elements[2].equals("unknown")) {
				int groupId = Integer.parseInt(elements[1]);
				//int value = elements[3].equals("positive")?1:-1;
				String wsId = elements[4];
				if (map.get(wsId)==null) {
					map.put(wsId, new PNOSentiment());
				}
				if (elements[3].equals("positive")) {
					map.get(wsId).pos++;
				} else {
					map.get(wsId).neg++;
				}
			}
			
			
		}
		//System.out.println("linesRead="+linesRead);
		
//		ArrayList<PNOSentiment> valueList = new ArrayList<>(map.values());
//		PNOSentiment.normalizeList(valueList);
//		System.out.println(Java2Python.collection2list(valueList));
		
		return map;
	}



}
