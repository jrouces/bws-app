package se.spraakbanken.bwsannotation;

import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

import org.rouces.jac.jutils.StringPythonable;

public class PNOSentiment implements StringPythonable {

	public double pos, neg;
	
	public double confidence = 0;

	public PNOSentiment() {

	}
	
	public PNOSentiment(PNOSentiment other) {
		pos = other.pos;
		neg = other.neg;
		confidence = other.confidence;
	}
	
	/**
	 * For manually assigned sentiments. POS,NEG,OBJ
	 * 
	 * @param vector
	 * @return 
	 */
	public PNOSentiment(double[] vector) {
		pos = vector[0];
		neg = vector[1];
	}
	
	public PNOSentiment(double pos, double neg) {
		this.pos = pos;
		this.neg = neg;
	}
	
	public void multiplySubjectiveSentimentDimensionsByScalar(double scalar) {
		if (scalar<0) {
			double poss = neg*Math.abs(scalar);
			neg = pos*Math.abs(scalar);
			pos = poss;
		} else {
			pos = pos*scalar;
			neg = neg*scalar;
		}
	}
	
	public void add(PNOSentiment other) {
		pos += other.pos;
		neg += other.neg;
		confidence += other.confidence;
	}
	
//	public void normalize() {
//		double sum = pos+neg+obj;
//		pos = pos/sum;
//		neg = neg/sum;
//		obj = obj/sum;
//	}

	/**
	 * pos-neg, it will be between -1 and 1
	 * @return
	 */
	public double getSen() {
		return pos-neg;
	}

	private static DecimalFormat df2 = new DecimalFormat("0.00");
	private static DecimalFormat df5 = new DecimalFormat("0.00000");

	
	@Override
	public String toString() {
		return "pos="+df2.format(pos)+" , neg="+df2.format(neg)+" , sen="+df2.format(getSen());
	}
	
//	/**
//	 * 
//	 * @param set
//	 */
//	public static void normalizeList(List<PNOSentiment> list) {
//		double max = Stream.concat(
//				list.stream().map((s)->Math.abs(s.getPos())),
//				list.stream().map((s)->Math.abs(s.getPos()))).max(Double::compare).get();
//		for (PNOSentiment e : list) {
//			e.multiplySubjectiveSentimentDimensionsByScalar(1/max);
//			e.normalize();
//		}
//	}

	@Override
	public String toPythonString() {
		return "["+pos+","+neg+"]";
	}
	
	
	public double getPos() {
		return pos;
	}

	public void setPos(double pos) {
		this.pos = pos;
	}

	public double getNeg() {
		return neg;
	}

	public void setNeg(double neg) {
		this.neg = neg;
	}

//	public double getObj() {
//		return obj;
//	}
//
//	public void setObj(double obj) {
//		this.obj = obj;
//	}

	public double getConfidence() {
		return confidence;
	}

	public void setConfidence(double confidence) {
		this.confidence = confidence;
	}
	
}
