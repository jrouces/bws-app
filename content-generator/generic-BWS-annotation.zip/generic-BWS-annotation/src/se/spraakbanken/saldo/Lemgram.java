package se.spraakbanken.saldo;

import java.util.HashSet;
import java.util.Set;

public class Lemgram {
	
	private String lemgramId;
	
	/** aka citation form */
	public String lemma;
	
	/**
	The POS labels are basically those introduced in early corpus work in 
	Gothenburg, documented in works such as /Nusvensk frekvensordbok/.

	Two-letter labels denote single (and full) orthographic words:

	ab – adverb
	al – article
	av – adjective
	in – interjection
	kn – conjunction
	nl – numeral
	nn – common noun
	pm – proper noun
	pn – pronoun
	pp – preposition
	sn – subjunction
	vb – verb

	If you tack an "m" onto the end of these, they will designate multi-word 
	expressions.

	An "a" at the end indicates abbreviations/acronyms.

	An "h" at the end means something that only appears as the last element 
	of a compound, but not as a free word.

	And, finally, "sxc" are non-last compound parts that don't appear as 
	free words.

	
	*/
	public String pos;
	public String inflectionalParadigmId;
	
	public Lemgram(String lemgramId) {
		this.lemgramId = lemgramId;
	}

	public String getId() {
		return lemgramId;
	}
	
	public String getLemma() {
		return lemma;
	}

	public String getPos() {
		return pos;
	}
	
	public String getPosInLayEnglish() {
		switch (pos.substring(0, 2)) {
			case "ab" : return "adverb"; 
			case "al" : return "article"; 
			case "av" : return "adjective"; 
			case "in" : return "interjection"; 
			case "kn" : return "conjunction"; 
			case "nl" : return "number"; 
			case "nn" : return "noun"; 
			case "pm" : return "noun"; 
			case "pn" : return "pronoun"; 
			case "pp" : return "preposition"; 
			case "sn" : return "subjunction"; 
			case "vb" : return "verb"; 
		};
		return pos;
	}
	
	public String getPosInLaySwedish() {
		switch (pos.substring(0, 2)) {
			case "ab": return "adverb";
			case "al": return "artikel";
			case "av": return "adjektiv";
			case "in": return "interjektion";
			case "kn": return "konjunktion";
			case "nl": return "nummer";
			case "nn": return "substantiv";
			case "pm": return "substantiv";
			case "pn": return "pronomen";
			case "pp": return "preposition";
			case "sn": return "subjunction";
			case "vb": return "verb";
		};
		return pos;
	}
	
}
