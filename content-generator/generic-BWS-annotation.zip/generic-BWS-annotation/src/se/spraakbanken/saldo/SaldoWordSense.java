package se.spraakbanken.saldo;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class SaldoWordSense implements Serializable, Comparable<SaldoWordSense> {

	private static final long serialVersionUID = 6167904533918647470L;
	
	private String senseString;
	private int senseNumber;
	
	private SaldoWordSense primaryDescriptor;
	private List<SaldoWordSense> secondaryDescriptors;

	public List<Lemgram> lemgrams;

	public static final SaldoWordSense PRIM = new SaldoWordSense("PRIM",1);
	
	static {
		PRIM.primaryDescriptor = PRIM;
	}
	
	public SaldoWordSense() {
		secondaryDescriptors = new LinkedList<SaldoWordSense>();
		lemgrams = new LinkedList<Lemgram>();
	}
	/**
	 * From SENSESTRING..SENSENUM format
	 * @param senseId
	 */
	public SaldoWordSense(String senseId) {
		this();
		String[] components = senseId.split("\\.\\.");
		this.senseString = components[0];
		this.senseNumber = Integer.parseInt(components[1]);
		//sentVecConfidence = -1;
	}
	
	public SaldoWordSense(String senseString, String senseNumber) {
		this();
		this.senseString = senseString;
		this.senseNumber = Integer.parseInt(senseNumber);
	}
	
	public SaldoWordSense(String senseString, int senseNumber) {
		this();
		this.senseString = senseString;
		this.senseNumber = senseNumber;
		//sentVecConfidence = -1;
	}
	
	public String getSenseString() {
		return senseString;
	}
	public void setSenseString(String senseString) {
		this.senseString = senseString;
	}
	public int getSenseNumber() {
		return senseNumber;
	}
	public void setSenseNumber(int senseNumber) {
		this.senseNumber = senseNumber;
	}
	
	public String getId() {
		return senseString+".."+senseNumber;
	}
	
	public String getIdPadded() {
		return String.format("%1$20s",getId());
	}

	public List<SaldoWordSense> getSecondaryDescriptors() {
		return secondaryDescriptors;
	}
	public void addSecondaryDescriptor(SaldoWordSense secondaryDescriptor) {
		this.secondaryDescriptors.add(secondaryDescriptor);
	}
	
	@Override
	public String toString() {
		return senseString+".."+senseNumber;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((senseString == null) ? 0 : senseString.hashCode());
		result = prime * result + senseNumber;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SaldoWordSense other = (SaldoWordSense) obj;
		if (senseString == null) {
			if (other.senseString != null)
				return false;
		} else if (!senseString.equals(other.senseString))
			return false;
		if (senseNumber != other.senseNumber)
			return false;
		return true;
	}
	
	

	/**
	 * -1 for negation words, (0,2) for quantifiers
	 * @return .
	 */
	public double getModifierValueAsSecondaryDescritor() {
		if (senseString.equals("inte")||senseString.equals("motsats")) {
			return -1;
		} else if (senseString.equals("lite")) {
			return 0.5;
		} else if (senseString.equals("mycket")) {
			return 1.5;
		} else if (senseString.equals("enestående")||senseString.equals("värdelös")) {
			return 2;
		} else {
			return 1;
		}
	}


//	public boolean isNegation() {
//		return toString().equals("inte..1")||toString().equals("motsats..1");
//	}
	
	public static void main(String[] args) {
		System.out.println(new SaldoWordSense("god",1).equals(new SaldoWordSense("god",1)));
		System.out.println(new SaldoWordSense("god",1).equals(new SaldoWordSense("god",2)));

	}

	@Override
	public int compareTo(SaldoWordSense o) {
		return this.toString().compareTo(o.toString());
	}

	public SaldoWordSense getPrimaryDescriptor() {
		return primaryDescriptor;
	}

	public void setPrimaryDescriptor(SaldoWordSense primaryDescriptor) {
		this.primaryDescriptor = primaryDescriptor;
	}

//	public String getReadableListOfLemgrams(String separator) {
//		StringBuilder sb = new StringBuilder();
//		for (Lemgram lemgram : lemgrams) {
//			sb.append(lemgram.lemma + separator);
//		}
//		sb.delete(Math.max(sb.length()-separator.length(),0), sb.length());
//		return sb.toString();
//	}
	
}
