package org.rouces.jac.jutils.datastructures.relations;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * Models a mathematical relation wrapping as a set of pairs and provides methods to use it as a function when possible.
 * Remember A and B must re-implement equals and hash methods properly!
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class RelationWithPrecomputedMaps<A,B> {

	public Set<Pair<A,B>> pairs;
	private Map<A,B> forwardFunctionalMap;
	private Map<B,A> backwardFunctionalMap;
	private Map<A,Set<B>> forwardNaryMap;
	private Map<B,Set<A>> backwardNaryMap;
	
	public static void main(String[] args) {
		RelationWithPrecomputedMaps<String,String> relation = new RelationWithPrecomputedMaps<String,String>();
		relation.addPair("2", "3");
		relation.addPair("2", "4");
		relation.addPair("5", "4");
		System.out.println(relation.existsPair("2", "4"));
		System.out.println(relation.getForwardFunctionalElement("5"));
	}
	
	public RelationWithPrecomputedMaps() {
		pairs = new LinkedHashSet<Pair<A,B>>();
		forwardFunctionalMap = new HashMap<A,B>();
		backwardFunctionalMap = new HashMap<B,A>();
		forwardNaryMap = new HashMap<A,Set<B>>();
		backwardNaryMap = new HashMap<B,Set<A>>();
	}

	/* (non-Javadoc)
	 * @see org.rouces.jac.jutils.datastructures.RelationInterface#addPair(A, B)
	 */
	public void addPair(A a, B b) {
		pairs.add(new Pair<A, B>(a, b));
		forwardFunctionalMap.put(a, b);
		backwardFunctionalMap.put(b, a);
		if (forwardNaryMap.get(a)==null) {
			Set<B> newSet = new HashSet<B>();
			newSet.add(b);
			forwardNaryMap.put(a, newSet);
		} else {
			forwardNaryMap.get(a).add(b);
		}
		if (backwardNaryMap.get(b)==null) {
			Set<A> newSet = new HashSet<A>();
			newSet.add(a);
			backwardNaryMap.put(b, newSet);
		} else {
			backwardNaryMap.get(b).add(a);
		}
	}
	
	/* (non-Javadoc)
	 * @see org.rouces.jac.jutils.datastructures.RelationInterface#existsPair(A, B)
	 */
	public boolean existsPair(A a, B b) {
		return pairs.contains(new Pair<A, B>(a, b));
	}
	
	/**
	 * Returns null if none.
	 */
	public B getForwardFunctionalElement(A a) {
		return forwardFunctionalMap.get(a);
	}
	
	/**
	 * Returns null if none.
	 */
	public A getBackwardFunctionalElement(B b) {
		return backwardFunctionalMap.get(b);
	}
	
	/**
	 * Returns an empty set if none
	 */
	public Set<B> getForwardNaryElements(A a) {
		return forwardNaryMap.get(a)!=null?forwardNaryMap.get(a):new HashSet<B>();
	}
	
	/**
	 * Returns an empty set if none
	 */
	public Set<A> getBackwardNaryElements(B b) {
		return backwardNaryMap.get(b)!=null?backwardNaryMap.get(b):new HashSet<A>();
	}
	
}
