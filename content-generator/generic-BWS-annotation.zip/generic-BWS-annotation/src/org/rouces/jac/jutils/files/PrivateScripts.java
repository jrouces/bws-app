package org.rouces.jac.jutils.files;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * Miscellaneous scripts not to be called from outside.
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
class PrivateScripts {


	public static void main(String[] args) {
		
		try {
			
			
			
			//findDuplicatedLineInFile();
			
			findDuplicatedSynsetsInClusterFile();
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * Finds all duplicate lines
	 * @throws IOException
	 */
	private static void findDuplicatedLineInFile() throws IOException {
		BufferedReader list = new BufferedReader(new FileReader("/home/jacobo/Dropbox/work/data/framebase/integrated/clusters.txt"));
		String line;
		Set<String> previousLines = new HashSet<String>();
		Set<String> duplicateLines = new HashSet<String>();
		while ((line = list.readLine()) != null) {
			if (previousLines.contains(line)) {
				if (!duplicateLines.contains(line)) {
					System.out.println(line);
				}
				duplicateLines.add(line);
			}
			previousLines.add(line);
		}
		System.out.print(duplicateLines.size()+" DUPLICATE LINES EXIST");
		list.close();
	}
	
	
	
	/**
	 * Finds all duplicate SYNSETS
	 * @throws IOException
	 */
	private static void findDuplicatedSynsetsInClusterFile() throws IOException {
		int synsetsInheritingMoreThanOneFrame = 0;
		BufferedReader list = new BufferedReader(new FileReader("/home/jacobo/Dropbox/work/data/framebase/integrated/clusters.txt"));
		String line1;
		Set<String> lines = new HashSet<String>();
		Set<String> duplicateLines = new HashSet<String>();
		while ((line1 = list.readLine()) != null) {
			if (!line1.startsWith("http://framebase.org/ns/"))
				continue;
			if (!Character.isDigit(line1.charAt(line1.length()-1))) 
				continue;
			lines.add(line1);
		}
		for (String line : lines) {
			if (duplicateLines.contains(line))
				continue;
			boolean alreadyOnefound = false;
			String[] lineChunks = line.split("-");
			String lastPartLine = lineChunks[lineChunks.length-1];
			for (String otherLine : lines) {
				if (line.equals(otherLine))
					continue;
				if (duplicateLines.contains(otherLine))
					continue;
				String[] otherLineChunks = otherLine.split("-");
				String lastPartOtherLine = otherLineChunks[otherLineChunks.length-1];
				if (lastPartLine.equals(lastPartOtherLine)) {
					if (!alreadyOnefound) {
						synsetsInheritingMoreThanOneFrame++;
						System.out.println("");
						System.out.println(line);
						duplicateLines.add(line);
					}
					System.out.println(otherLine);
					duplicateLines.add(otherLine);
					alreadyOnefound = true;
				}
			}
		}
		System.out.print("synsetsInheritingMoreThanOneFrame="+synsetsInheritingMoreThanOneFrame);
		list.close();
	}
	
	
}
