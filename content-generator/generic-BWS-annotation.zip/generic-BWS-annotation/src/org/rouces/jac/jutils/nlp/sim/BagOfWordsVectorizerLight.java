package org.rouces.jac.jutils.nlp.sim;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.rouces.jac.jutils.datastructures.SparseVector;
import org.tartarus.snowball.ext.EnglishSnowballStemmer;

/**
 * Bag of words tools that are lightweight.
 * TODO  add implements BagOfWordsVectorizer
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class BagOfWordsVectorizerLight {

	private static EnglishSnowballStemmer stemmer = new EnglishSnowballStemmer();
	private String splitPattern;

	public BagOfWordsVectorizerLight() {
		this.splitPattern = "[^a-z]+";
	}
	
	public BagOfWordsVectorizerLight(String splitPattern) {
		this.splitPattern = splitPattern;
	}
	
	public SparseVector<String> tokenizeWithCount(String text){
		SparseVector<String> bagOfWords = new SparseVector<String>();
		List<String> tokenized = new LinkedList<String>(listTokenize(text));
		for (String word : tokenized) {
			if ((!Stopwords.stopwords.is(word))&&(word.length()>0)) {
				bagOfWords.addElement(stem(word));
			}
		}
		return bagOfWords;
	}
	
	public Set<String> tokenizeWithoutStemming(String text){
		Set<String> bagOfWords = new HashSet<String>(listTokenize(text));
		bagOfWords.remove("");
		return bagOfWords;
	}
	
	public void removeStopwords(Set<String> in){
		in.removeAll(Stopwords.stopwords.getSet());
	}

	
	/**
	 * Uses the same stemmer as the tokenizer method
	 * @param word
	 * @return
	 */
	public static String stem(String word) {
		stemmer.setCurrent(word);
		stemmer.stem();
		return stemmer.getCurrent();
	}
	
	public List<String> listTokenize(String text) {
		return Arrays.asList(text.toLowerCase().split(splitPattern));
	}
	
}
