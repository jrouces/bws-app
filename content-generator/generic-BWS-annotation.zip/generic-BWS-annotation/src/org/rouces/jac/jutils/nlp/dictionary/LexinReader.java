package org.rouces.jac.jutils.nlp.dictionary;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.rouces.jac.jutils.Directories;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * Reads a Lexin dictionary
 * 
 * @author Jacobo Rouces <jacobo@rouces.org>
 *
 */
public class LexinReader {
	
	public static Lemma2LemmaDictionary loadLemma2LemmaDictionary(String filePath) {
		
		System.out.println(filePath);
		
		Lemma2LemmaDictionary dict = new Lemma2LemmaDictionary();
		
		File folder = new File(filePath);
		File[] listOfFiles = folder.listFiles();
		for (int i = 0; i < listOfFiles.length; i++) {
		    if (listOfFiles[i].isFile()&&listOfFiles[i].getName().matches(".\\.xml")) {
		    	//System.out.println(listOfFiles[i].getName());
		    	
		    	try {
					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
					DocumentBuilder builder = factory.newDocumentBuilder();
					Document doc = builder.parse(listOfFiles[i]);
					
					NodeList words = doc.getElementsByTagName("Word");
					
					for (int j = 0; j < words.getLength(); j++) {
						Node word = words.item(j);
						String lemma1 = word.getAttributes().getNamedItem("Value").getTextContent();
						//System.out.println(lemma1);
						Node translationsNode = ((Element)word).getElementsByTagName("Translation").item(0);
						if (translationsNode!=null) {
							String translations = translationsNode.getTextContent();
							//System.out.println(translations);
							translations = translations.replaceAll("\\(.*\\)", "").replaceAll("\\[.*\\]", "");
							String[] translationsArr = translations.split("[,;]");
							for (String translation : translationsArr) {
								translation = translation.trim();
								//System.out.println(translation);
								dict.addPair(lemma1, translation);
							}
						}
						//System.out.println("");

					}
					
//					XPathFactory xPathfactory = XPathFactory.newInstance();
//					XPath xpath = xPathfactory.newXPath();
//					XPathExpression expr = xpath.compile("/Word/@Value");
//					
//					String str = expr.evaluate(doc);
//					
//					System.out.println(str);
					
				} catch (ParserConfigurationException | SAXException | IOException e) {
					e.printStackTrace();
				}
		    	
		    }
		    //break;
		}
		
		return dict;
	}
	
	/**
	 * Test
	 * @param args
	 */
	public static void main(String[] args) {
		Lemma2LemmaDictionary swe2engDict = LexinReader.loadLemma2LemmaDictionary(
				Directories.getDataDir(null)+
				"lexin svensk dictionary\\XML_Engelska080601");
		System.out.println(swe2engDict.lemma2lemmas.get("mycket"));

		Lemma2LemmaDictionary eng2sweDict = swe2engDict.getReverse();
		System.out.println(eng2sweDict.lemma2lemmas.get("house"));

	}

}
