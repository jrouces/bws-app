package org.rouces.jac.jutils.files;

import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;

/**
 * Utils for deleting files
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class FileDeleter {

	public static void main(String[] args) {
		
		///home/jacobo/Sync/work/old projects/pfc/pfc entregado/src
		
		List<Path> fileNames = new LinkedList<Path>();
		Path root = FileSystems.getDefault().getPath( "dgfgzsg" );
		getFilesRecursively(fileNames, root).stream().forEach((path)->{
			if (path.toString().endsWith(".asv")) {  
				path.toFile().delete();
                System.out.println("Deleted:"+path.toAbsolutePath());
			}
		});
	}
	


	/**
	 * For security reasons, use this instead of external methods. 
	 * So no surprises with changes, and this one can be run alone first and just print the selection.
	 * 
	 * Returns input.
	 * 
	 * @param fileNames
	 * @param root
	 * @return
	 */
	public static List<Path> getFilesRecursively(List<Path> fileNames, Path root) {
	    try(DirectoryStream<Path> stream = Files.newDirectoryStream(root)) {
	        for (Path path : stream) {
	            if(path.toFile().isDirectory()) {
	            	getFilesRecursively(fileNames, path);
	            } else {
	                fileNames.add(path);
	                System.out.println("Selected:"+path.toAbsolutePath());
	            }
	        }
	    } catch(IOException e) {
	        e.printStackTrace();
	    }
	    return fileNames;
	} 
	
	/**
	 * Works recursively
	 * @param dir
	 * @return
	 */
	public static boolean deleteDir(File dir) {
	    if (dir.isDirectory()) {
	        String[] children = dir.list();
	        for (int i=0; i<children.length; i++) {
	            boolean success = deleteDir(new File(dir, children[i]));
	            if (!success) {
	                return false;
	            }
	        }
	    }
	    return dir.delete();
	}
	
	
}

