package org.rouces.jac.jutils;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.rouces.jac.jutils.Directories.Location;
import org.rouces.jac.jutils.FileSamplerForTests.Repetitions;
import org.rouces.jac.jutils.datastructures.Multiset;
import org.rouces.jac.jutils.datastructures.relations.Pair;
import org.rouces.jac.jutils.system.SystemAlt;
import org.rouces.jac.jutils.textfiles.TextFileWriter;
import org.rouces.jac.jutils.textfiles.TextFileWriterInterface;
import org.rouces.jac.jutils.textfiles.TextFileWriterInterface.Mode;

/**
 * Contains generic methods for sampling lines in plain text files and later averaging manual evaluations made for each line.
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class FileSamplerForTests {

	public enum Repetitions {WITH, WITHOUT};
	
	public static int offset = 0;
	
	/**
	 * Takes randomly sampleSize lines from file inputFileName and writes it in inputFileName+"_sampled"
	 * withRepetitions indicates if the random sample is taken with repetitions.
	 * @param inputFileName
	 * @param sampleSize
	 */
	public static void shuffleFile(String inputFileName, String pattern, int sampleSize, Repetitions repetitions) {

		TextFileWriterInterface fileOut = new TextFileWriter(inputFileName+"_shuffled", Mode.ERASE);
		
		Map<Integer,String> elements = new HashMap<Integer,String>();
        File file = new File(inputFileName);
        Scanner scnr = null;
		try {
			scnr = new Scanner(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		StringBuilder sb = new StringBuilder();
		//// Reads the lines
		while(scnr.hasNextLine()){
			String element = scnr.nextLine();
			//System.out.println(element);
			sb.append(element+"\n");
		} 
		
		int line = 0;
		for (String chunk : sb.toString().split(pattern)) {
			elements.put(line++,chunk);
		}
		
		if (sampleSize<=0) {
			sampleSize = elements.size();
		}

		List<Integer> ruleIdxList = new LinkedList<Integer>();
		if (repetitions==Repetitions.WITH) {
			//// With repetitions
			Random randomGenerator = new Random();
			for (int idx = 0; idx < sampleSize; idx++){
				ruleIdxList.add(randomGenerator.nextInt(elements.size()));
			}
		} else {
			//// Without repetitions
		    for (int idx = 0; idx < elements.size(); idx++){
		    	ruleIdxList.add(idx);
		    }
			Collections.shuffle(ruleIdxList);
			ruleIdxList = ruleIdxList.subList(0, sampleSize);
		}


		for (Integer idx : ruleIdxList) {
			fileOut.print(elements.get(idx)+pattern);
		}
		
		fileOut.close();
	}
	
	/**
	 * Takes randomly sampleSize lines from file inputFileName and writes it in inputFileName+"_sampled"
	 * withRepetitions indicates if the random sample is taken with repetitions.
	 * @param inputFileName
	 * @param sampleSize
	 */
	public static void sampleFile(String inputFileName, int sampleSize, Repetitions repetitions) {

		TextFileWriterInterface fileOut = new TextFileWriter(inputFileName+"_sampled", Mode.ERASE);
		
		Map<Integer,String> elements = new HashMap<Integer,String>();
        File file = new File(inputFileName);
        Scanner scnr = null;
		try {
			scnr = new Scanner(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		//// Skips the offset
		for(int i=0; i<offset; i++){
			scnr.nextLine();
		} 
		//// Reads the lines
		int line = 0;
		while(scnr.hasNextLine()){
			elements.put(line++,scnr.nextLine());
		} 


		List<Integer> ruleIdxList = new LinkedList<Integer>();
		if (repetitions==Repetitions.WITH) {
			//// With repetitions
			Random randomGenerator = new Random();
			for (int idx = 0; idx < sampleSize; idx++){
				ruleIdxList.add(randomGenerator.nextInt(elements.size()));
			}
		} else {
			//// Without repetitions
		    for (int idx = 0; idx < elements.size(); idx++){
		    	ruleIdxList.add(idx);
		    }
			Collections.shuffle(ruleIdxList);
			ruleIdxList = ruleIdxList.subList(0, sampleSize);
		}


		for (Integer idx : ruleIdxList) {
//			fileOut.out.println("?1## (Element "+String.format("%06d", idx)+") "+elements.get(idx));
			fileOut.println("<correct=1> <quality=> (Element "+String.format("%06d", idx)+") "+elements.get(idx));
		}
		
		fileOut.close();
	}
	
	/**
	 * Reads evaluated file and evaluates field
	 * For field values "+1" or "-1" it returns also the average precision and the wilson 95% ci.
	 * @param inputFileName
	 */
	public static void readEvaluatedFile(String inputFileName, String field) {
		
		Pattern pattern = Pattern.compile("<"+field+"=([\\d+-\\.]*?)>");
		
		double numberOfAnswers  = 0;
		double accumulatedScore = 0;
		Multiset<String> answers = new Multiset<String>();
		
		File file = new File(inputFileName);
        Scanner scnr = null;
		try {
			scnr = new Scanner(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		while(scnr.hasNextLine()){
			String line = scnr.nextLine();
			if (line.startsWith("#"))
				continue;
			Matcher matcher = pattern.matcher(line);
			matcher.find();
			try{
				String answer = matcher.group(1);
				//System.out.println("answer="+answer);//
				answers.addElement(answer);
				double newValue = scoreLibrary(answer);
				accumulatedScore = accumulatedScore + newValue;
				numberOfAnswers++;
			} catch (Exception e) {
				//e.printStackTrace();
			}
		}
		
		System.out.println("Results for <"+field+"> at "+inputFileName);
		System.out.println(answers.toString());
		double averageScore = accumulatedScore/numberOfAnswers;
		System.out.println("accumulatedScore = " + accumulatedScore + " , numberOfAnswers="+numberOfAnswers);
		System.out.println("Average score = " + averageScore + " , Wilson="+EvaluationUtils.wilsonScoreInterval(averageScore,numberOfAnswers));

		
	}
	
	/**
	 *  Returns the numerical score of an answer
	 * @param answer
	 * @return numerical score of an answer
	 */
	public static double scoreLibrary(String answer) throws NumberFormatException {
		
			double value = Double.parseDouble(answer);
			//System.out.println("double value="+value);
			
			return value;
			
			//// -1->0
			//return (value<0)?0:value;

	}
	
	



	public int getOffset() {
		return offset;
	}



	public void setOffset(int offset) {
		this.offset = offset;
	}
	
}
