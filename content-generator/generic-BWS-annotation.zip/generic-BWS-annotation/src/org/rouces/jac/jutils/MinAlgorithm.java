package org.rouces.jac.jutils;

/**
 * Same methods as the Hungarian algortihm but just choosing the min.
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class MinAlgorithm {
	
	private final int dim, rows, cols;
	private final double[][] costMatrix;
	private double maxAllowed;

	/**
	 * Just for testing
	 * @param args
	 */
	public static void main(String[] args) {
		
	}

	/**
	 * Construct an instance of the algorithm.
	 * 
	 * @param costMatrix
	 *            the cost matrix, where matrix[i][j] holds the cost of
	 *            assigning worker i to job j, for all i, j. The cost matrix
	 *            must not be irregular in the sense that all rows must be the
	 *            same length.
	 */
	public MinAlgorithm(double[][] costMatrix) {
		this.dim = Math.max(costMatrix.length, costMatrix[0].length);
		this.rows = costMatrix.length;
		this.cols = costMatrix[0].length;
		this.costMatrix = costMatrix;
		maxAllowed = Double.MAX_VALUE;
	}

	


	/**
	 * Execute the algorithm.
	 * 
	 * @return the minimum cost matching of workers to jobs based upon the
	 *         provided cost matrix. A matching value of -1 indicates that the
	 *         corresponding worker is unassigned.
	 *         Length of returned array is the number of rows of the matrix (first dim, height)
	 */
	public int[] execute() {
		/*
		 * Heuristics to improve performance: Reduce rows and columns by their
		 * smallest element, compute an initial non-zero dual feasible solution
		 * and create a greedy matching from workers to jobs of the cost matrix.
		 */
		
		int[] result = new int[rows];
		for (int r = 0; r < result.length; r++) {
			double min = Double.MAX_VALUE;
			for (int c = 0; c < costMatrix[0].length; c++) {
				if (costMatrix[r][c]<min) {
					result[r] = c;
					min = costMatrix[r][c];
					if (costMatrix[r][c]>=maxAllowed) {
						result[r] = -1;
					}
				}
			}
		}
		return result;
	}

	public void setMaxAllowed(double maxAllowed) {
		this.maxAllowed = maxAllowed;
	}

}