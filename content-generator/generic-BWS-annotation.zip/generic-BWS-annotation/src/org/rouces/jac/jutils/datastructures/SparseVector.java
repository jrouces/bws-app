package org.rouces.jac.jutils.datastructures;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

/**
 * Sparse vector in the Cartesian space double^T.
 * Works also as a multiset of elements of type T that allows double instead of int indices.
 * 
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class SparseVector<T extends Serializable & Comparable<T>> implements Serializable {
	

		private static final long serialVersionUID = 1025034242793717119L;
	

	
		/** Should not include zeros*/
		private Map<T,Double> elementToValueMap;

		public Map<T, Double> getElementToValueMap() {
			return elementToValueMap;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((elementToValueMap == null) ? 0 : elementToValueMap.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			@SuppressWarnings("unchecked")
			SparseVector<T> other = (SparseVector<T>) obj;
			if (elementToValueMap == null) {
				if (other.elementToValueMap != null)
					return false;
			} else if (!elementToValueMap.equals(other.elementToValueMap))
				return false;
			return true;
		}

		public SparseVector() {
			super();
			elementToValueMap = new HashMap<T,Double>();
		}
		
		public SparseVector(Collection<T> collection) {
			this();
			for (T element : collection) {
				addElement(element);
			}
		}
		
		/**
		 * Note that if the map comes from another vector, it should already be copied.
		 * @param elementToValueMap
		 */
		public SparseVector(Map<T,Double> elementToValueMap) {
			this();
			this.elementToValueMap = elementToValueMap;
		}
		
		/**
		 * Adds the element with value 1, summing to the existing value if it already exists
		 * @param element
		 * @return .
		 */
		public SparseVector<T> addElement(T element) {
			addElementWithValue(element, 1);
			return this;
		}
		
		/**
		 * Adds the element with a specific value, summing to the existing value if it already exists
		 * @param element
		 * @param value 
		 * @return .
		 */
		public SparseVector<T> addElementWithValue(T element, double value) {
			if (elementToValueMap.containsKey(element)) {
				elementToValueMap.put(element, elementToValueMap.get(element)+value);
			} else {
				if (value!=0)
					elementToValueMap.put(element, value);
			}
			return this;
		}
		
		/**
		 * Add element with a specific value, substituting if exists.
		 * @param element
		 * @param value
		 * @return .
		 */
		public SparseVector<T> putElementWithValue(T element, double value) {
			if (value!=0)
				elementToValueMap.put(element, value);
			else
				elementToValueMap.remove(element);
			return this;
		}


		public double getSumOfIndices() {
			int total = 0;
			for(Double count : elementToValueMap.values()) {
				total += count;
			}
			return total;
		}
		
		public double getNumOfNonzeroElements() {
			// For this to work, it is necessary to avoid zero elements in the map!
			return elementToValueMap.size();
		}
		
		public boolean isZero() {
			// For this to work, it is necessary to avoid zero elements in the map!
			return elementToValueMap.size()==0;
		}
		
		@Override
		public String toString() {
			return elementToValueMap.toString();
		}
		
		public static <K, V extends Comparable<? super V>> LinkedHashMap<K, V> sortByIncreasingValue(Map<K, V> map) {
		    return map.entrySet()
		              .stream()
		              .sorted(Map.Entry.comparingByValue())
		              .collect(Collectors.toMap(
		                Map.Entry::getKey, 
		                Map.Entry::getValue, 
		                (e1, e2) -> e1, 
		                LinkedHashMap::new
		              ));
		}
		
		public static <K, V extends Comparable<? super V>> LinkedHashMap<K, V> sortByDecreasingValue(Map<K, V> map) {
		    return map.entrySet()
		              .stream()
		              .sorted(Map.Entry.comparingByValue(Collections.reverseOrder()))
		              .collect(Collectors.toMap(
		                Map.Entry::getKey, 
		                Map.Entry::getValue, 
		                (e1, e2) -> e1, 
		                LinkedHashMap::new
		              ));
		}
		
		/**
		 * 
		 * @return .
		 */
		public String toStringSortedIncreasing() {
			LinkedHashMap<T,Double> orderedMap = sortByIncreasingValue(elementToValueMap);
			StringBuilder sb = new StringBuilder("{");
			for (Iterator<T> iterator = orderedMap.keySet().iterator(); iterator.hasNext();) {
				T key = iterator.next();
				sb.append("("+key.toString()+","+orderedMap.get(key).toString()+")");
			}
			sb.append("}");
			return sb.toString();
		}
		
		/**
		 * 
		 * 
		 */
		public void printSortedIncreasing() {
			LinkedHashMap<T,Double> orderedMap = sortByIncreasingValue(elementToValueMap);
			for (Iterator<T> iterator = orderedMap.keySet().iterator(); iterator.hasNext();) {
				T key = iterator.next();
				System.out.println(String.format("%1$-20s %2$5s", key.toString(), orderedMap.get(key).toString()));
			}
		}
		
		/**
		 * 
		 * @return .
		 */
		public String toStringSortedDecreasing() {
			LinkedHashMap<T,Double> orderedMap = sortByDecreasingValue(elementToValueMap);
			StringBuilder sb = new StringBuilder("{");
			for (Iterator<T> iterator = orderedMap.keySet().iterator(); iterator.hasNext();) {
				T key = iterator.next();
				sb.append("("+key.toString()+","+orderedMap.get(key).toString()+")");
			}
			sb.append("}");
			return sb.toString();
		}
		
		/**
		 * 
		 * 
		 */
		public void printSortedDecreasing() {
			LinkedHashMap<T,Double> orderedMap = sortByDecreasingValue(elementToValueMap);
			for (Iterator<T> iterator = orderedMap.keySet().iterator(); iterator.hasNext();) {
				T key = iterator.next();
				System.out.println(String.format("%1$-20s %2$5s", key.toString(), orderedMap.get(key).toString()));
			}
		}
		

		
		public double getMultiplicityOfElement(T element) {
			if (elementToValueMap.containsKey(element)) {
				return elementToValueMap.get(element);
			} else {
				return 0;
			}
		}
		
		public void multiplyElementDimension(T element, double scalar) {
			if (elementToValueMap.containsKey(element)) {
				elementToValueMap.put(element,elementToValueMap.get(element)*scalar);
			}
		}
		
		/**
		 * Use if the other methods do not suit you.
		 * This should be removed and wrap all possible operations, in order to avoid zero-valued elements.
		 * @return
		 */
		public Map<T, Double> getMap() {
			return elementToValueMap;
		}
		
		/**
		 * Normalizes this vector.
		 * If parameter=1, the normalization is complete.
		 * If parameter=0; there is no normalization.
		 * If parameter is in between 0 and 1, the normalization is partial.
		 * Be careful, parameter here is not p for p-norm. This uses 2-norm always.
		 * Returns this, but modifies the object.
		 * @param parameter
		 */
		public SparseVector<T> normalize(double parameter) {
			if (parameter==0) {
				return this;
			}
			double denominator = ((this.getPNorm(2)-1)*parameter+1);
			for (T element : elementToValueMap.keySet()) {
				elementToValueMap.put(element, elementToValueMap.get(element)/denominator); 
			}
			return this;
		}
		
		/**
		 * Normalizes this vector using p-norm
		 * Attention: p>0
		 * Returns this, but modifies the object.
		 * @param parameter
		 */
		public SparseVector<T> pNormalize(double p) {
			double denominator = this.getPNorm(p);
			for (T element : elementToValueMap.keySet()) {
				elementToValueMap.put(element, elementToValueMap.get(element)/denominator); 
			}
			return this;
		}
		
		/**
		 * Returns sum of elements to the power of p
		 * @param p
		 */
		public double getPNormPoweredToP(double p){
			double squaredNorm = 0;
			for (double value : elementToValueMap.values()) {
				if (p==1) {
					squaredNorm += Math.abs(value);
				} else {
					squaredNorm += Math.pow(value, p);
				}
			}
			return squaredNorm;
		}
		
		/**
		 * Returns p-norm, i.e. getPowerNorm^(1/p)
		 * @param p
		 */
		public double getPNorm(double p){
			if (p==1) {
				return getPNormPoweredToP(1);
			} else {
				return Math.pow(getPNormPoweredToP(p), 1/p);
			}
		}
		
		/**
		 * Multiplies vector with scalar.
		 * Returns itself but also MODIFIES THIS OBJECT
		 */
		public SparseVector<T> multiplyByScalar(double scalar) {
			for (T element : elementToValueMap.keySet()) {
				elementToValueMap.put(element, elementToValueMap.get(element)*scalar);
			}
			return this;
		}
		
		/**
		 * Add another vector to this.
		 * More efficient if the other is the sparser vector.
		 * MODIFIES THIS OBJECT
		 */
		public SparseVector<T> addOtherVector(SparseVector<T> other) {
			for (T element : other.getMap().keySet()) {
				if (elementToValueMap.containsKey(element)) {
					elementToValueMap.put(element, other.getMap().get(element)+elementToValueMap.get(element));
					//System.out.println("c:"+elementToValueMap.get(element));
					//System.out.println("c:"+other.getMap().get(element));
					//System.out.println("c:"+other.getMap().get(element)+elementToValueMap.get(element));
				} else {
					elementToValueMap.put(element, other.getMap().get(element));
					//System.out.println("o:"+other.getMap().get(element));
				}
			}
			return this;
		}
		
		/**
		 * Multiplies vector with other vector, elementwise.
		 * More efficient if the other is the sparser vector.
		 * Returns a new vector. Does not modify the others.
		 */
		public SparseVector<T> multiplyElementwise(SparseVector<T> other) {
			SparseVector<T> elementWiseProduct = new SparseVector<T>();
			for (T element : other.getMap().keySet()) {
				if (elementToValueMap.containsKey(element)) {
					elementWiseProduct.addElementWithValue(element, other.getMap().get(element)*elementToValueMap.get(element));
				}
			}
			return elementWiseProduct;
		}
		
		/**
		 * Returns outer product with another vector
		 */
		public double getOuterProduct(SparseVector<T> other) {
			double product = 0;
			SparseVector<T> smaller = this;
			SparseVector<T> bigger = other;
			if (other.getNumOfNonzeroElements()>this.getNumOfNonzeroElements()) {
				smaller = other;
				bigger = this;
			}
			for (T element : smaller.getMap().keySet()) {
				Double value = bigger.getMap().get(element);
				if (value==null)
					continue;
				product += value*smaller.getMap().get(element);
			}
			return product;
		}
		
		
		
	/**
	 * Not symmetric! The argument is the inner set
	 */
	public double getIncludes(SparseVector<T> innerVector, double threshold) {
		//return getMap().keySet().containsAll(innerVector.getMap().keySet())?1:0;
		for (T element : innerVector.getMap().keySet()) {
			if (!this.getMap().containsKey(element)&&innerVector.getElementValue(element)>threshold) {
				 return 0;
			}
		}
		return 1;
	}
	
	public double getWeightedJaccard(SparseVector<T> other) {
		double num = 0;
		for (T element : other.getMap().keySet()) {
			if (this.getMap().containsKey(element)) {
				num += Math.min(this.getMap().get(element), other.getMap().get(element));
			}
		}
		double den = 0;
		Set<T> union = new HashSet<T>();
		union.addAll(this.getMap().keySet());
		union.addAll(other.getMap().keySet());
		for (T element : union) {
			if (this.getMap().containsKey(element)) {
				num += Math.max(this.getMap().get(element), other.getMap().get(element));
			}
		}
		return num/den;
	}
	



		public double getElementValue(T element) {
			return elementToValueMap.get(element)!=null?elementToValueMap.get(element):0;
		}
		
		public T getElementWithMaxValue() {
			Set<T> keySet = elementToValueMap.keySet();
			T elementWithMaxValue = null;
			double maxValue = Double.NEGATIVE_INFINITY;
			for (T key : keySet) {
				if (elementToValueMap.get(key)>maxValue) {
					maxValue = elementToValueMap.get(key);
					elementWithMaxValue = key;
				}
			}
			return elementWithMaxValue;
		}
		
		/**
		 * Creates a clone with a new underlying HashMap, but it does not copy the elements of the map in case these are complex mutable objects.
		 */
		public SparseVector<T> clone() {
			SparseVector<T> clone = new SparseVector<T>(new HashMap<T,Double>(elementToValueMap));
			return clone;
		}

		
		
		
		
		
		
		
		
		
		
		
		/**
		 * Tests
		 * @param args
		 */
		public static void main(String[] args) {
			
			SparseVector<String> vectorA = new SparseVector<String>();
			vectorA.addElement("1");
			vectorA.addElement("2");
			vectorA.addElement("3");
			vectorA.addElement("4");
			vectorA.normalize(1);


			SparseVector<String> vectorB = new SparseVector<String>();
			vectorB.addElement("1");
			vectorB.addElement("2");
			vectorB.addElement("3");
			vectorB.normalize(1);


			//vectorB.addElement("this is out");
			
			//vectorA.normalize(1);
			System.out.println(vectorA.toString());
			
			//vectorA.multiplyByScalar(2);
			System.out.println(vectorA.getOuterProduct(vectorB));
			
			
			SparseVector<String> vectorToOrder = new SparseVector<String>();
			vectorToOrder.addElementWithValue("one",1);
			vectorToOrder.addElementWithValue("three",3);
			vectorToOrder.addElementWithValue("four",4);
			vectorToOrder.addElementWithValue("two",2);
			vectorToOrder.addElementWithValue("five",5);
			vectorToOrder.addElementWithValue("ten",10);

			//System.out.println("vectorToOrder.toStringSortedIncreasing()="+vectorToOrder.toStringSortedIncreasing());
			//System.out.println("vectorToOrder.toStringSortedDecreasing()="+vectorToOrder.toStringSortedDecreasing());

			System.out.println(vectorToOrder);
			LinkedHashMap<String,Double> orderedMap = sortByIncreasingValue(vectorToOrder.elementToValueMap);
			//LinkedHashMap<String,Double> orderedMap = sortByDecreasingValue(vectorToOrder.elementToValueMap);
			System.out.println("xxx");
			for (Iterator<String> iterator = orderedMap.keySet().iterator(); iterator.hasNext();) {
				String key = iterator.next();
				System.out.println(String.format("%1$-10s %2$5s", key.toString(), orderedMap.get(key).toString()));
			}
			
		}
		
		public int getNumberOfElementsWithValue(double v) {
			int n = 0;
			for (T e : elementToValueMap.keySet()) {
				if (elementToValueMap.get(e)==v) {
					n++;
				}
			}
			return n;
		}
		

}


