package org.rouces.jac.jutils.files;

import java.io.File;
import java.util.LinkedList;
import java.util.List;
import java.util.regex.Pattern;

public class DirectoryExploringUtils {


	
	/**
	 * Returns a list with all the files recursively from each of the directories in the input, excluding those beginning with "." and "omit_".
	 * Filters filenames by regex. Recursive folders not affected by regex
	 * @param filesOrFolders
	 * @return
	 */
	public static List<String> listFilesRecursivelyRegexFilter(String regexFilter, String... filesOrFolders) {
		if (regexFilter==null) {
			regexFilter = ".*";
		}
		Pattern pattern = Pattern.compile(regexFilter);
		List<String> list = new LinkedList<String>();
		for (String fileOrFolder : filesOrFolders) {
			System.out.println(fileOrFolder);
			File fileEntry = new File(fileOrFolder);
	    	if (fileEntry.getName().startsWith(".")||fileEntry.getName().startsWith("omit_")) {
	    		continue;
	    	}
	        if (fileEntry.isDirectory()) {
	        	listFilesRecursivelyBRegexFilter(list, fileEntry, pattern);
	        } else {
	   		 	if (pattern.matcher(fileEntry.getName()).matches()) {
		            list.add(fileEntry.getAbsolutePath());
	   		 	} else {
	   		 		System.out.println("File does not match regex, excluded: "+fileEntry.getAbsolutePath());
	   		 	}
	        }
		}
	    return list;
	}
	
	/**
	 * Returns a list with all the files recursively from each of the directories in the input, excluding those beginning with "." and "omit_".
	 * @param filesOrFolders
	 * @return
	 */
	public static List<String> listFilesRecursively(String... filesOrFolders) {
		return listFilesRecursivelyRegexFilter(".*",filesOrFolders);
	}
	
	private static void listFilesRecursivelyBRegexFilter(List<String> list, final File folder, Pattern pattern) {
	    for (final File fileEntry : folder.listFiles()) {
	    	if (fileEntry.getName().startsWith(".")||fileEntry.getName().startsWith("omit_")) {
	    		continue;
	    	}
	        if (fileEntry.isDirectory()) {
	        	listFilesRecursivelyBRegexFilter(list, fileEntry, pattern);
	        } else {
	   		 	if (pattern.matcher(fileEntry.getName()).matches()) {
	   		 		list.add(fileEntry.getAbsolutePath());
	   		 	}
	        }
	    }
	}
	
	/**
	 * Returns a list with all the files from each of the directories in the input, excluding those beginning with "." and "omit_".
	 * NO recursion.
	 * @param filesOrFolders
	 * @return
	 */
	public static List<String> listFiles(String... filesOrFolders) {
		List<String> list = new LinkedList<String>();
		for (String fileOrFolder : filesOrFolders) {
			System.out.println(fileOrFolder);
			File fileEntry = new File(fileOrFolder);
	    	if (fileEntry.getName().startsWith(".")||fileEntry.getName().startsWith("omit_")) {
	    		continue;
	    	}
	        if (fileEntry.isDirectory()) {
	    		for (File fileEntry2 : fileEntry.listFiles()) {
	    	    	if (fileEntry2.getName().startsWith(".")||fileEntry2.getName().startsWith("omit_")) {
	    	    		continue;
	    	    	}
	    	        if (fileEntry2.isDirectory()) {
	    	        	// Nothing
	    	        } else {
	    	            list.add(fileEntry2.getAbsolutePath());
	    	        }
	    		}
	        } else {
	            list.add(fileEntry.getAbsolutePath());
	        }
		}
	    return list;
	}
	
}
