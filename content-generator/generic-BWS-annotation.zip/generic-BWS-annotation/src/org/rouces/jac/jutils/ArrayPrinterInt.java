package org.rouces.jac.jutils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Edit only ArrayPrinterD.o.u.b.l.e and copy changing:
 *  - double -> int
 *  - Double -> Integer
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class ArrayPrinterInt {

	public static void array1dToCsvFile(int[] array, String fileStr){
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(fileStr));
			for (int element : array) {
				br.write(Integer.toString(element));
				br.write("\n");
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}



	public static void array2dToCsvFile(int[][] array, String fileStr){
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(fileStr));
			for (int i = 0; i<array.length; i++) {
				for (int j = 0; j<array[i].length; j++) {
					br.write(Integer.toString(array[i][j]));
					if (j==array[i].length-1) {
						br.write("\n");
					} else {
						br.write(",");	
					}						
				}
			}			
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void array3dToCsvFile(int[][][] array, String fileStr){
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(fileStr));
			for (int i = 0; i<array.length; i++) {
				// Important that k and j are in this order
				for (int k = 0; k<array[0][0].length; k++) {
					for (int j = 0; j<array[0].length; j++) {
						br.write(Integer.toString(array[i][j][k]));
						br.write(",");	
						if (j==array[0].length-1) {
							br.write("\n");
						} else {
							br.write(",");	
						}
					}		
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static String array1dToStr(int[] array){
		StringBuilder sb = new StringBuilder();
		for (int element : array) {
			sb.append(element);
			sb.append("\n");
		}
		return sb.toString();
	}

	public static String array2dToStr(int[][] array){
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i<array.length; i++) {
			for (int j = 0; j<array[i].length; j++) {
				sb.append(array[i][j]);
				if (j==array[i].length-1) {
					sb.append("\n");
				} else {
					sb.append(",");	
				}						
			}
		}
		return sb.toString();
	}






}
