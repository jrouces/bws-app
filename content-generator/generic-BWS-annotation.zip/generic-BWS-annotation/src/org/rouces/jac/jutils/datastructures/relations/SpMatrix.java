package org.rouces.jac.jutils.datastructures.relations;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;

public class SpMatrix<A,B> {

	/**
	 * Adjacency list
	 */
	public Map<A,Set<B>> alMap;
	
	/**
	 * Zeros not allowed.
	 * Contains double iff a2bMap entry exists.
	 */
	public Map<Pair<A,B>,Double> entries;
	
	public SpMatrix() {
		super();
		alMap = new HashMap<>();
		entries = new HashMap<>();
	}
	
	public SpMatrix(SpMatrix<A,B> other) {
		super();
		alMap = new HashMap<>(other.alMap);
		entries = new HashMap<>(other.entries);
	}
	
	public double getWeight(A a, B b) {
		Double e = entries.get(new Pair<A,B>(a, b));
		if (e==null) {
			return 0;
		} else {
			return e;
		}
	}

	public SpMatrix<A,B> elementwiseOperationWith(SpMatrix<A,B> other, BiFunction<Double,Double,Double> f) {
		Set<A> unionDomains = new HashSet<>(alMap.keySet());
		unionDomains.addAll(other.alMap.keySet());
		SpMatrix<A,B> result = new SpMatrix<>();
		for (A a : unionDomains) {
			Set<B> values = new HashSet<>(alMap.get(a));
			values.addAll(other.alMap.get(a));
			for (B b : values) {
				result.setEntry(a, b, f.apply(getWeight(a,b),other.getWeight(a, b)));
			}
		}
		return result;
	}
	
	public SpMatrix<A,B> elementwiseOperation(Function<Double,Double> f) {
		SpMatrix<A,B> copy = new SpMatrix<>();
		for (A a : alMap.keySet()) {
			for (B b : alMap.get(a)) {
				double newValue = f.apply(this.getWeight(a, b));
				if (newValue!=0) {
					copy.setEntry(a, b,newValue);
				}
			}
		}
		return copy;
	}
	
	public SpMatrix<A,B> elementwiseMultiplication(double m) {
		if (m==0) {
			return new SpMatrix<>();
		}
		return elementwiseOperation(x->x*m);
	}


	
	public void setEntry(A a, B b, double e) {
		if (e!=0) {
			setEntryInAlMap(a, b);
			entries.put(new Pair<A,B>(a, b), e);
		}
	}
	
	private void setEntryInAlMap(A a, B b) {
		if (alMap.get(a)==null) {
			Set<B> newSet = new HashSet<B>();
			newSet.add(b);
			alMap.put(a, newSet);
		} else {
			alMap.get(a).add(b);
		}
	}
	
	public <C> SpMatrix<A,C> concatenateWith(SpBinaryMatrix<B,C> other, BiFunction<Double,Double,Double> f) {
		SpMatrix<A,C> concatenation = new SpMatrix<>();
		for (A a : alMap.keySet()) {
			for (B b : alMap.get(a)) {
				for (C c : other.alMap.get(b)) {
					double e = f.apply(entries.get(new Pair<A,B>(a, b)), entries.get(new Pair<B,C>(b, c)));
					concatenation.setEntry(a, c, e);					
				}
			}
		}
		return concatenation;
	}
	
	public SpBinaryMatrix<A,B> toBinary() {
		SpBinaryMatrix<A,B> output = new SpBinaryMatrix<>(this.alMap);
		return output;
	}
	
	public static void main(String[] args) {

	}

}
