package org.rouces.jac.jutils.system;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryType;

import org.rouces.jac.jutils.textfiles.TextFileWriter;


/**
 * Extension of System class.
 * 
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class SystemAlt {

	public static void main(String[] args) {
		SystemAlt.tic();
		System.out.println(SystemAlt.toc());
		System.out.println(SystemAlt.getHeapUsageDescription());

	}
	
	public enum Verbosity{
		  DEBUG(4), HIGH(3) ,MEDIUM(2), LOW(1), NONE(0);
		  public int id;
		  Verbosity(int id){
		    this.id = id;
		  }
		}
	
	
	private static PrintStream _out, _err;
	
	/**
	 * Like System.out but prints to a file ~/out
	 */
	public static PrintStream out;

	/**
	 * Method version. Ensures flushing.
	 * @param str
	 */
	public static void out_println(String str) {
		out.println(str);
		out.flush();
	}
	
	/**
	 * Method version. Ensures flushing.
	 * @param str
	 */
	public static void out_print(String str) {
		out.print(str);
		out.flush();
	}
	
	/**
	 * Like System.err but prints to a file ~/err
	 */
	public static PrintStream err;
	
	/**
	 * Method version. Ensures flushing.
	 * @param str
	 */
	public static void err_println(String str) {
		err.println(str);
		err.flush();
	}
	
	/**
	 * Method version. Ensures flushing.
	 * @param str
	 */
	public static void err_print(String str) {
		err.print(str);
		err.flush();
	}
	
	/**
	 * Used to calculate elapsed time.
	 */
	public static long lastTime;
	
	/**
	 * Ping counter
	 */
	private static int hiCounter = 0;
	
	static {
		try {
			File outFile = new File("./out");
			if(!outFile.exists()) {
				outFile.createNewFile();
			}
			_out = new PrintStream(new FileOutputStream(outFile, false));
			out = _out;
			File errFile = new File("./err");
			if(!errFile.exists()) {
				errFile.createNewFile();
			}
			_err = new PrintStream(new FileOutputStream(errFile, false));
			err = _err;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * This should be automated with some kind of "last method".
	 */
	public static void close() {
		out.flush();
		out.close();
		err.flush();
		err.close();
	}
	
	public static void exit(int status) {
		if (status>0)
			System.err.println("Exit with error code: "+status);
		close();
		TextFileWriter.closeAll();
		System.exit(status);
	}
	
	public static void exit() {
		exit(0);
	}
	
	public static void tic() {
		lastTime = System.nanoTime();
	}
	
//	public static void toc() {
//		System.out.println("Elapsed time = "+(double)(System.nanoTime()-lastTime)/10e6+" ms.");
//		lastTime = System.nanoTime();
//	}
	
	/**
	 * Returns a string that states the time elapsed since last tic() in human-readable format.
	 * @return
	 */
	public static String toc() {
		double millis = (double)(System.nanoTime()-lastTime)/1e6;
		lastTime = System.nanoTime();
		return "Elapsed time = "+String.format("%f",millis)+" ms.";
	}
	
	/**
	 * Prints "Hi", hiCounter value and increments
	 */
	public static void hi() {
		System.out.println("Hi "+(hiCounter++)+" !");
	}
	
	/**
	 * If you want to filter prints containing a string, you have to edit the code if this method.
	 */
	public static void findNastySystemOutPrintln() {
		System.setOut(new java.io.PrintStream(
		        new java.io.FileOutputStream(java.io.FileDescriptor.out)) {
		    @Override
		    public void print(String s) {
		        super.print(s);
		        if (s.contains("10")) {
		            throw new RuntimeException("Found you!");
		        }
		    }
		});
	}
	
	public static void redirectToStandardOutput() {
		SystemAlt.out = System.out;
		SystemAlt.err = System.err;
	}
	
	public static void redirectToFileOutput() {
		SystemAlt.out = _out;
		SystemAlt.err = _err;
	}
	
/**
 * Returns formatted strings with 3 rows.
 * Max heap size specified for the VM seems to be roughly equal to the sum of the three max'es
 * @return
 */
public static String getHeapUsageDescription() {
	StringBuilder sb = new StringBuilder();
	for (MemoryPoolMXBean mpBean: ManagementFactory.getMemoryPoolMXBeans()) {
	    if (mpBean.getType() == MemoryType.HEAP) {
	    	sb.append(String.format(
	            "%20s: %s\n",
	            mpBean.getName(), mpBean.getUsage()
	        ));
	    }
	}
	return sb.toString();
}
	
}
