package org.rouces.jac.jutils;

public interface StringPythonable {

		public String toPythonString();
	
}