package org.rouces.jac.jutils.nlp.dictionary;

public enum Language {
	SWE,ENG
}
