package org.rouces.jac.jutils.nlp.sim;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Collections;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//
//import javatools.filehandlers.FileLines;
//
//import com.aliasi.chunk.Chunk;
//import com.aliasi.chunk.Chunking;
//import com.aliasi.dict.DictionaryEntry;
//import com.aliasi.dict.ExactDictionaryChunker;
//import com.aliasi.dict.TrieDictionary;
//import com.aliasi.tokenizer.IndoEuropeanTokenizerFactory;
//
//import org.apache.lucene.util.Version;
//
public class Chunker {
//
//	/*
//	 * public static final Set<?> ENGLISH_STOP_WORDS_SET;
//	 * 
//	 * static { final List<String> stopWords = Arrays.asList("0", "1", "2", "3",
//	 * "4", "5", "6", "7", "8", "9", "000", "$", "about", "after", "all",
//	 * "also", "an", "and", "another", "any", "are", "as", "at", "be",
//	 * "because", "been", "before", "being", "between", "both", "but", "by",
//	 * "came", "can", "come", "could", "did", "do", "does", "each", "else",
//	 * "for", "from", "get", "got", "has", "had", "he", "have", "her", "here",
//	 * "him", "himself", "his", "how", "if", "in", "into", "is", "it", "its",
//	 * "just", "like", "make", "many", "me", "might", "more", "most", "much",
//	 * "must", "my", "never", "now", "of", "on", "only", "or", "other", "our",
//	 * "out", "over", "re", "said", "same", "see", "should", "since", "so",
//	 * "some", "still", "such", "take", "than", "that", "the", "their", "them",
//	 * "then", "there", "these", "they", "this", "those", "through", "to",
//	 * "too", "under", "up", "use", "very", "want", "was", "way", "we", "well",
//	 * "were", "what", "when", "where", "which", "while", "who", "will", "with",
//	 * "would", "you", "your", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j",
//	 * "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x",
//	 * "y", "z"); final CharArraySet stopSet = new
//	 * CharArraySet(Version.LUCENE_44, stopWords.size(), false);
//	 * stopSet.addAll(stopWords); ENGLISH_STOP_WORDS_SET =
//	 * CharArraySet.unmodifiableSet(stopSet); }
//	 */
//
//	TrieDictionary<String> dict = new TrieDictionary<String>();
//	ExactDictionaryChunker chunker;
//
//	public Chunker(String mappingsFile) {
//
//		// LoggerFactory.getLogger(this.getClass()).info("Loading ...");
//
//		try {
//			FileLines fl = new FileLines(mappingsFile);
//
//			for (String line : fl) {
//				String[] entries = line.split("\t");
//				dict.addEntry(new DictionaryEntry<String>(entries[0]
//						.toLowerCase(), entries[1]));
//			}
//			fl.close();
//		} catch (IOException e) {
//			e.printStackTrace();
//			throw new RuntimeException(e);
//		}
//		chunker = new ExactDictionaryChunker(dict,
//				new IndoEuropeanTokenizerFactory(), false, true);
//
//		// LoggerFactory.getLogger(this.getClass()).info("Finished loading.");
//	}
//
//	public Chunking chunk(String str) {
//		return chunker.chunk(str);
//	}
//
//	/**
//	 * @param args
//	 */
//	public static void main(String[] args) {
//
//		String mappingsFile = args[0];
//		String str = args[1];
//
//		Chunker ch = new Chunker(mappingsFile);
//
//		try {
//
//			Chunking chuncking = ch.chunk(str.toLowerCase());
//
//			List<Chunk> orderedChunks = new ArrayList<Chunk>();
//
//			for (Chunk chunk : chuncking.chunkSet()) {
//				// don't tag stop words.
//				// if
//				// (ENGLISH_STOP_WORDS_SET.contains(str.substring(chunk.start(),
//				// chunk.end()).toLowerCase())) {
//				// continue;
//				// }
//				orderedChunks.add(chunk);
//			}
//
//			Collections.sort(orderedChunks, Chunk.TEXT_ORDER_COMPARATOR);
//			Collections.reverse(orderedChunks);
//
//			for (Chunk chunk : orderedChunks) {
//				str = str.substring(0, chunk.end())
//						+ "</tag>"
//						+ " "
//						+ (chunk.end() < str.length() ? str.substring(
//								chunk.end() + 1, str.length()) : "");
//				str = str.substring(0, chunk.start()) + "<tag map=\""
//						+ chunk.type() + "\">"
//						+ str.substring(chunk.start(), chunk.end())
//						+ str.substring(chunk.end(), str.length());
//
//			}
//
//			System.out.println(str + "\t" + str);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//	}
}