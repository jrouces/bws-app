package org.rouces.jac.jutils.onto;

/**
 * POJO for ontological property, or binary predicate.
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class Property extends Entity {

	protected Entity domain, range;

	// Constructors
	
	protected Property() {
	}
	
	public Property(String id) {
		super(id);
	}
	
	public Property(String id, String name) {
		super(id, name);
	}
	
	public Property(String id, String name, String description) {
		super(id, name, description);
	}
	
	// Getters and setters
	
	public boolean hasDomain() {
		return domain!=null;
	}
	
	public Entity getDomain() {
		return domain!=null?domain:new Entity();
	}

	public void setDomain(Entity domain) {
		this.domain = domain;
	}

	public boolean hasRange() {
		return range!=null;
	}
	
	public Entity getRange() {
		return range!=null?range:new Entity();
	}

	public void setRange(Entity range) {
		this.range = range;
	}



	@Override
	public String toString() {
		return "Property {\n"
				+ "id=" + id + "\n"
				+ "name=" + name + "\n"
				+ "description=" + description + "\n"
				+ "domain=" + (domain==null?"":domain.toString()) + "\n"
				+ "range=" + (range==null?"":range.toString()) + "\n"
				+ "}";
	}
	
	
	
}
