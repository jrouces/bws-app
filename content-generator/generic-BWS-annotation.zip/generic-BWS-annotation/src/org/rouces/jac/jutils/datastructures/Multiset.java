package org.rouces.jac.jutils.datastructures;

import java.util.HashMap;
import java.util.Map;

/**
 * Each instance of Multiset allows to keep track of a multiset of elements of type T, and provides convenience methods for adding and printing.
 * Public static fields can be created to refer to particular instances from anywhere in the project.
 * 
 * @deprecated SparseVector, which is more general, should be used instead.
 * 
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 * @param <T>
 */
public class Multiset<T> {

	// Static public fields
	public static Multiset<String> exampleStringMs;
	
	private Map<T,Integer> elementToMultiplicityMap;

	public Multiset() {
		super();
		elementToMultiplicityMap = new HashMap<T,Integer>();
	}
	
	/**
	 * Adds the element to the set, and if it exists, increments the counter.
	 * @param element
	 */
	public void addElement(T element) {
		addElementNTimes(element, 1);
	}
	
	/**
	 * Adds the element to the set N times.
	 * @param element
	 */
	public void addElementNTimes(T element, int times) {
		if (elementToMultiplicityMap.containsKey(element)) {
			elementToMultiplicityMap.put(element, elementToMultiplicityMap.get(element)+times);
		} else {
			elementToMultiplicityMap.put(element, times);
		}
	}

	public int getTotalElements() {
		int total = 0;
		for(int count : elementToMultiplicityMap.values()) {
			total += count;
		}
		return total;
	}
	
	@Override
	public String toString() {
		return elementToMultiplicityMap.toString();
	}
	

	public int getMultiplicityOfElement(T element) {
		if (elementToMultiplicityMap.containsKey(element)) {
			return elementToMultiplicityMap.get(element);
		} else {
			return 0;
		}
	}
	
	/**
	 * Use if the other methods do not suit you.
	 * @return
	 */
	public Map<T, Integer> getElementToMultiplicityMap() {
		return elementToMultiplicityMap;
	}
	
}
