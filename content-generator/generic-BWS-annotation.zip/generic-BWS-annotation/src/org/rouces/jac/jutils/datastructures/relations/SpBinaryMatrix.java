package org.rouces.jac.jutils.datastructures.relations;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * 
 * Sparse matrix or relation
 * Remember A and B must re-implement equals and hash methods properly!
 * 
 * @author Jacobo Rouces <jacobo@rouces.org>
 *
 * @param <A>
 * @param <B>
 */
public class SpBinaryMatrix<A,B> {

	/**
	 * Adjacency list
	 */
	public Map<A,Set<B>> alMap;

	public SpBinaryMatrix() {
		super();
		alMap = new HashMap<>();
	}
	
	public SpBinaryMatrix(Map<A,Set<B>> alMap) {
		super();
		this.alMap = new HashMap<>(alMap);
	}
	
	public SpBinaryMatrix(SpBinaryMatrix<A,B> other) {
		super();
		alMap = new HashMap<>(other.alMap);
	}
	
	public void setEntry(A a, B b) {
		if (alMap.get(a)==null) {
			Set<B> newSet = new HashSet<B>();
			newSet.add(b);
			alMap.put(a, newSet);
		} else {
			alMap.get(a).add(b);
		}
	}
	
	public boolean hasEntry(A a, B b) {
		if (alMap.containsKey(a)&&alMap.get(a).equals(b)) {
			return true;
		} else {
			return false;
		}
	}
	
	public Set<B> getElements(A a) {
		return alMap.get(a);
	}
	
	public Set<A> getDomain() {
		return alMap.keySet();
	}
	
	public Set<B> getRange() {
		Set<B> range = new HashSet<>();
		for (Set<B> sb : alMap.values()) {
			range.addAll(sb);
		}
		return range;
	}
	
	public SpBinaryMatrix<B,A> getInverse() {
		SpBinaryMatrix<B,A> inverse = new SpBinaryMatrix<>();
		for (A a : alMap.keySet()) {
			for (B b : alMap.get(a)) {
				inverse.setEntry(b, a);
			}
		}
		return inverse;
	}
	
	public <C> SpBinaryMatrix<A,C> concatenateWith(SpBinaryMatrix<B,C> other) {
		SpBinaryMatrix<A,C> concatenation = new SpBinaryMatrix<>();
		for (A a : alMap.keySet()) {
			for (B b : alMap.get(a)) {
				for (C c : other.alMap.get(b)) {
					concatenation.setEntry(a, c);
				}
			}
		}
		//a2bMap.forEach((a, sb)->{sb.forEach(b->{other.a2bMap.get(b).forEach(c -> {concatenation.addElements(a, c);});});});
		return concatenation;
	}
	
	public SpBinaryMatrix<A,B> createUnion(SpBinaryMatrix<A,B> other) {
		SpBinaryMatrix<A,B> union = new SpBinaryMatrix<>();
		for (A a : alMap.keySet()) {
			for (B b : alMap.get(a)) {
				union.setEntry(a, b);
			}
		}
		for (A a : other.alMap.keySet()) {
			for (B b : other.alMap.get(a)) {
				union.setEntry(a, b);
			}
		}
		return union;
	}
	
	public SpBinaryMatrix<A,B> createIntersectionWith(SpBinaryMatrix<A,B> other) {
		SpBinaryMatrix<A,B> intersection = new SpBinaryMatrix<>();
		for (A a : alMap.keySet()) {
			for (B b : alMap.get(a)) {
				if (other.alMap.containsKey(a)&&other.alMap.get(a).equals(b)) {
					intersection.setEntry(a, b);
				}
			}
		}
		return intersection;
	}
	
	public SpMatrix<A,B> toNonBinary() {
		SpMatrix<A,B> output = new SpMatrix<>();
		output.alMap = new HashMap<>(this.alMap);
		output.entries = new HashMap<>();
		for (A a : alMap.keySet()) {
			for (B b : alMap.get(a)) {
				output.entries.put(new Pair<A,B>(a, b), 1.0);
			}
		}
		return output;
	}

//	/**
//	 * Assumes binary matrix.
//	 * @param a
//	 * @param b
//	 * @return
//	 */
//	public double getWeight(A a, B b) {
//		if (alMap.containsKey(a)&&alMap.get(a).equals(b)) {
//			return 1;
//		} else {
//			return 0;
//		}
//	}
	
}
