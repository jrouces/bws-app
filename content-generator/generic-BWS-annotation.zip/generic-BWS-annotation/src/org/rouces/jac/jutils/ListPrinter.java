package org.rouces.jac.jutils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collection;

/**
 * Prints arrays.
 * Contains static methods for standard out, static methods for primitive types and non-static methods for generic types.
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 * @param <T>
 */
public class ListPrinter<T> {

	/**
	 * Prints collection in a file, each element separated with separator.
	 * @param collection
	 * @param fileStr
	 */
	public void collection1dToFile(Collection<T> collection, String separator, String fileStr){
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(fileStr));
			for (T element : collection) {
				br.write(element.toString());
				br.write(separator);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Inefficient because it uses non-primitive wrappers!
	 */
	public void collection2dToCsvFile(Collection<Collection<T>> collection, String fileStr){
			throw new Error("Not implemented");
	}
	
	
}
