package org.rouces.jac.jutils.textfiles;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.LinkedList;
import java.util.List;

public class TextFileWriter implements TextFileWriterInterface {
	
	/**
	 * Example
	 * @param args
	 */
	public static void main(String[] args) {
		TextFileWriter tfw = new TextFileWriter("test.txt");
		tfw.println("hello world");
		tfw.close();
	}
	
	private static List<TextFileWriter> instances = new LinkedList<TextFileWriter>();
	
	/**
	 * It substitutes System.out but prints to a file.
	 */
	public PrintStream out, err;
	
	private File file;
	
	public TextFileWriter(String fileName) {
		this(fileName,Mode.ERASE);
	}
	
	public TextFileWriter(String fileName, Mode mode) {
		instances.add(this);
		try {
			file = new File(fileName);
			// Why this??
//			if(!file.exists()) {
//				file.getParentFile().mkdirs();
//				file.createNewFile();
//			}
			FileOutputStream fileOutputStream = new FileOutputStream(file, mode==Mode.APPEND);
			out = new PrintStream(fileOutputStream);
			err = out;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Prints and flushes
	 * @param string
	 */
	public synchronized void println(String string) {
		out.println(string);
		out.flush();
	}
	
	/**
	 * Prints and flushes
	 * @param string
	 */
	public synchronized void print(String string) {
		out.print(string);
		out.flush();
	}
	
	/**
	 * This should be automated with some kind of "last method".
	 */
	public void close() {
		out.close();
	}
	
	/**
	 * Closes all instances
	 */
	public static void closeAll() {
		for (TextFileWriter logger: instances) {
			System.out.println("Closing "+logger.toString());
			logger.close();
		}
	}
	
	/**
	 * JVM is supposed to call this...
	 */
	protected void finalize() throws Throwable {
		System.out.println("finalize() closing "+out.toString());
	     try {
	         close();
	     } finally {
	         super.finalize();
	     }
	 }
	
}
