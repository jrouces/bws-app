package org.rouces.jac.jutils;

import org.rouces.jac.jutils.datastructures.relations.Pair;

public class EvaluationUtils {

	/**
	 * Computes 95% Wilson score intervals. 
	 * The pEstimate parameter should be the accuracy on the random sample. The method returns a centre plus a delta, e.g. 0.84 +/- 0.04.
	 * 
	 * @param pEstimate
	 *            estimate of precision/accuracy based on sample data
	 * @param nSamples
	 *            number of samples
	 * @return pair with centre and delta
	 */
	public final static Pair<Double, Double> scoreInterval(double pEstimate, double nSamples) {
		double z = 1.95996398454005423552; 
		double d = z * Math.sqrt(pEstimate*(1-pEstimate)/nSamples);
		double centre = pEstimate;
		return new Pair<Double, Double>(centre, d);
	}
	
	/**
	 * From http://www.stat.wmich.edu/s160/book/node47.html
	 * @return pair with centre and delta
	 */
	public final static Pair<Double, Double> wilsonScoreInterval(double pEstimate, double nSamples) {
		double z = 1.95996398454005423552; 
		// Z_{(1-alpha)/2}, i.e. the 1-alpha/2 percentile of a standard normal distribution
		// cf. http://en.wikipedia.org/wiki/1.96
		double centre = (pEstimate + 1 / 2.0 / nSamples * z * z) / (1 + 1.0 / nSamples * z * z);
		double d = z * Math.sqrt((pEstimate * (1 - pEstimate) + 1 / 4.0 / nSamples * z * z) / nSamples) / (1 + z * z / nSamples);
		return new Pair<Double, Double>(centre, d);
	}



}
