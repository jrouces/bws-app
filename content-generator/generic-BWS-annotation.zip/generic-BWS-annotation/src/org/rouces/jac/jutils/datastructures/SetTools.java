package org.rouces.jac.jutils.datastructures;

import java.util.Set;

public class SetTools<E> {
	
	public double intersectionSize(Set<E> set1, Set<E> set2) {
		int sizeInt = 0;
		for (E element : set2) {
			if (set1.contains(element)) {
				sizeInt++;
			}
		}
		return (double) sizeInt;
	}

	public double jaccardSimilarity(Set<E> set1, Set<E> set2) {
		int size1 = set1.size();
		int sizeInt = 0;
		int size2m1 = 0;
		for (E element : set2) {
			if (set1.contains(element)) {
				sizeInt++;
			} else {
				size2m1++;
			}
		}
		//System.out.println((size1 + size2m1));
		return ((double) sizeInt) / (size1 + size2m1);
	}

//	public double jaccardSimilarityMod(Set<E> set1, Set<E> set2) {
//		int sizeh1 = set1.size();
//		//Retains all elements in h1 that are contained in h2 ie intersection
//		set1.retainAll(set2);
//		//h1 now contains the intersection of h1 and h2
//		//System.out.println("Intersection "+ set1);
//
//		set2.removeAll(set1);
//		//h2 now contains unique elements
//		//System.out.println("Unique in h2 "+ set2);
//
//		//Union 
//		int union = sizeh1 + set2.size();
//		int intersection = set1.size();
//
//		return ((double) intersection) / union;
//	}

	public double intersectionSizeStr(Set<String> set1, Set<String> set2) {
		int sizeInt = 0;
		for (String element : set2) {
			if (set1.contains(element)) {
				sizeInt++;
			}
		}
		return (double) sizeInt;
	}
	
	public static double jaccardSimilarityStr(Set<String> set1, Set<String> set2) {
		int size1 = set1.size();
		int sizeInt = 0;
		int size2m1 = 0;
		for (String element : set2) {
			if (set1.contains(element)) {
				sizeInt++;
			} else {
				size2m1++;
			}
		}
		//System.out.println((size1 + size2m1));
		return ((double) sizeInt) / (size1 + size2m1);
	}
	
//	/**
//	 * Does a simple split itself.
//	 * @param similar1
//	 * @param similar2
//	 * @return
//	 */
//	public static double jaccardSimilarityStr(String similar1, String similar2) {
//		HashSet<String> h1 = new HashSet<String>();
//		HashSet<String> h2 = new HashSet<String>();
//
//		for (String s : similar1.split("\\s+")) {
//			h1.add(s);
//		}
//		System.out.println("h1 " + h1);
//		for (String s : similar2.split("\\s+")) {
//			h2.add(s);
//		}
//		System.out.println("h2 " + h2);
//
//		return new SetTools<String>().jaccardSimilarity(h1, h2);
//
//	}

	public static void main(String args[]) {

	}
}