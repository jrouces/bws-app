package org.rouces.jac.jutils.system;

import java.util.Arrays;

/**
 * Returns list of strings left-aligned in fixed-width columns.
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class ColumnFormatter {

	private int width;
	
	public ColumnFormatter(int width) {
		super();
		this.width = width;
	}

	public String getRow(String... elements) {
		String row = "";
	    for(int i = 0; i < elements.length; i++){
	    	String element = elements[i]!=null? elements[i] : "";
	        int numberOfSpaces = width-element.length();
	        char[] chars = new char[numberOfSpaces];
	        Arrays.fill(chars, ' ');
	        row += element + new String(chars);
	    }
	    return row;
	}
	
}
