package org.rouces.jac.jutils.nlp.dictionary;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Lemma2LemmaDictionary {

	public Map<String,Set<String>> lemma2lemmas;
	
	public Lemma2LemmaDictionary() {
		lemma2lemmas = new HashMap<String, Set<String>>();
	}

	public void addPair(String l1, String l2) {
		if (lemma2lemmas.get(l1)==null) {
			lemma2lemmas.put(l1, new HashSet<String>());
		}
		lemma2lemmas.get(l1).add(l2);
	}
	
	public Lemma2LemmaDictionary getReverse() {
		Lemma2LemmaDictionary rev = new Lemma2LemmaDictionary();
		for (String l1 : lemma2lemmas.keySet()) {
			for (String l2 : lemma2lemmas.get(l1)) {
				rev.addPair(l2, l1);
			}
		}
		return rev;
	}
	
	public Set<String> getTranslations(String lemma1) {
		return lemma2lemmas.get(lemma1)==null?new HashSet<String>():lemma2lemmas.get(lemma1);
	}
	
}
