package org.rouces.jac.jutils.textfiles;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;

public class TextFileReaderStaticUtils {

	/**
	 * Return list with lines in file, void list if file is not found.
	 * @param fileStr
	 * @return
	 */
	public static List<String> getListOfLines (String fileStr) {
		try {
			return Files.readAllLines(Paths.get(fileStr),Charset.defaultCharset());
		} catch (IOException e) {
			System.out.println(e.getMessage()+"\n Returning empty list");
			//e.printStackTrace();
			return new LinkedList<String>();
		}
	}

	/**
	 * Returns true iff the file contains the line string.
	 * @return
	 */
	public boolean contains(String fileStr, String lineString) {
		try {
			List<String> lines = Files.readAllLines(Paths.get(fileStr),Charset.defaultCharset());
			for (String line : lines) {
				if (lineString.equals(line)) {
					return true;
				}
			}
		} catch (IOException e) {
			System.err.println("Error reading file: "+fileStr);
			e.printStackTrace();
		}
		return false;
	}


}
