

//No
// n't
//Not
//None
//No one
//Nobody
//Nothing
//Neither
//Nowhere
//Never

//
//Hardly
//Scarcely
//Barely
//rarely
// seldom

// little
// few
//seldom




//http://www.academypublication.com/issues/past/tpls/vol03/07/17.pdf

//(i) Full negatives: no, not, none, never, nothing, nobody, nowhere, neither, nor
//(ii) Absolute negatives: not at all, by no means, in no way, nothing short of, etc.
//(iii) Quasi negatives: hardly, scarcely, seldom, barely, few, little
//(iv) Partial negatives: not every, not all, not much, not many, not always, etc.
//(v) Words with neggative implication: fail, without, beyond, until, unless, lest, ignorant, refuse, neglect, absence,
//instead of, etc


