package org.rouces.jac.jutils.nlp.sim;

import org.tartarus.snowball.ext.EnglishSnowballStemmer;

public class SnowballEnglishStemmerWrapper {

	private static EnglishSnowballStemmer stemmer = new EnglishSnowballStemmer();
	
	public static String stem(String input) {
		stemmer.setCurrent(input);
		stemmer.stem();
		return stemmer.getCurrent();
	}

}
