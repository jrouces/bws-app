package org.rouces.jac.jutils.textfiles;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.rouces.jac.jutils.files.DirectoryExploringUtils;
import org.rouces.jac.jutils.textfiles.TextFileWriterInterface.Mode;

public class TextFileCatenator {
	
	public static void main(String[] args) {
		
	}
	
	/**
	 * For gzipped text files
	 * @param outputFile optional
	 * @param preamble optional
	 * @param filesOrFolders
	 */
	public static void catenateFilesGzip(String outputFile, String preamble, String... filesOrFolders) {
		if (outputFile==null) {
			File firstFile = new File(filesOrFolders[0]);
			//outputFile = new File(filesOrFolders[0]).getParent()+File.separator+"output.gz";
			//outputFile = firstFile.getParent()+File.separator+firstFile.getName()+"output.gz";
			outputFile = firstFile.toString()+".gz";
		}
		TextFileWriterInterface writer = new GzippedTxtFileWriter(outputFile);
		if (preamble!=null) {
			writer.println(preamble);
		}
		long numLines = 0;
		List<String> files = DirectoryExploringUtils.listFilesRecursivelyRegexFilter(".*\\.gz",filesOrFolders);
		for (String file  : files) {
			System.out.println("Reading "+file);
			TextFileReaderInterface reader = new GzippedTxtFileReader(file);
			String line;
			while ((line=reader.readLine())!=null) {
				writer.println(line);
				numLines++;
			}
			reader.close();
		}
		writer.close();
		System.out.println("Joined "+numLines+" lines from "+files.size()+" files");
	}
	
	/**
	 * For plain text files.
	 * @param outputFile optional
	 * @param preamble optional
	 * @param regex optional
	 * @param filesOrFolders
	 */
	public static void catenateFiles(String outputFile, String preamble, String regex, String... filesOrFolders) {
		if (outputFile==null) {
			outputFile = filesOrFolders[0]+".txt";
		}
		TextFileWriterInterface writer = new TextFileWriter(outputFile,Mode.ERASE);
		if (preamble!=null) {
			writer.println(preamble);
		}
		long numLines = 0;
		List<String> files = DirectoryExploringUtils.listFilesRecursivelyRegexFilter(regex,filesOrFolders);
		for (String file  : files) {
			TextFileReaderInterface reader = new TextFileReaderBR(file);
			String line;
			while ((line=reader.readLine())!=null) {
				writer.println(line);
				numLines++;
			}
			reader.close();
		}
		writer.close();
		System.out.println("Joined "+numLines+" lines from "+files.size()+" files");
	}
	
	/**
	 * 
	 * @param licenseNoticeFileStr 	The file indicating (not describing) the license.
	 * @param commentPrefix
	 * @return
	 */
	public static String getLicenseHeader(String licenseNoticeFileStr, String commentPrefix) {
		
		String partOfLine = commentPrefix+" This file is part of the FrameBase knowledge base.";
		StringBuilder sb = new StringBuilder();
		sb.append(partOfLine);
		try {
			BufferedReader br = new BufferedReader(new FileReader(licenseNoticeFileStr));
			String line;
			while ((line = br.readLine()) != null) {
			   sb.append(commentPrefix+" "+line+"\n");
			}
			sb.append("\n\n");
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return sb.toString();
	}

}
