package org.rouces.jac.jutils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Prints arrays.
 * For more efficient primitive-based ones, see ArrayPrinterDouble, ArrayPrinterInt, etc.
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 * @param <T>
 */
public class ArrayPrinter<T> {
	
    //// TO FILE
	//// ***************************
	
	/**
	 * Inefficient because it uses non-primitive wrappers.
	 */
	public void array1dToCsvFile(T[] array, String fileStr){
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(fileStr));
			for (T element : array) {
				br.write(element.toString());
				br.write("\n");
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Inefficient because it uses non-primitive wrappers.
	 */
	public void array2dToCsvFile(T[][] array, String fileStr){
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(fileStr));
			for (int i = 0; i<array.length; i++) {
				for (int j = 0; j<array[i].length; j++) {
					br.write(array[i][j].toString());
					if (j==array[i].length-1) {
						br.write("\n");
					} else {
						br.write(",");	
					}						
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Writes it like a 2d matrix.
	 * To convert back to 3d, use in matlab:
	 * M3d=reshape(M2d,[array.length,array[].length,array[][].length]);
	 * Inefficient because it uses non-primitive wrappers!
	 * @param array
	 * @param fileStr
	 */
	public void array3dToCsvFile(T[][][] array, String fileStr){
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(fileStr));
			for (int i = 0; i<array.length; i++) {
				// Important that k and j are in this order
				for (int k = 0; k<array[0][0].length; k++) {
					for (int j = 0; j<array[0].length; j++) {
						br.write(array[i][j][k].toString());
						br.write(",");	
						if (j==array[0].length-1) {
							br.write("\n");
						} else {
							br.write(",");	
						}
					}		
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

    //// TO STRING
	//// ***************************
	
	public String array1dToStr(T[] array) {
		StringBuilder sb = new StringBuilder();
		for (T element : array) {
			sb.append(element);
			sb.append("\n");
		}
		return sb.toString();
	}

	public String array2dToStr(T[][] array) {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i<array.length; i++) {
			for (int j = 0; j<array[i].length; j++) {
				sb.append(array[i][j]);
				if (j==array[i].length-1) {
					sb.append("\n");
				} else {
					sb.append(",");	
				}						
			}
		}
		return sb.toString();
	}

	
	
}
