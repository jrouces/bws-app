package org.rouces.jac.jutils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * This contains the same methods as ArrayPrinter but being static and for primitive doubles instead of generics.
 * For future edits, preferably paste code from ArrayPrinter and substitute. But expect bugs because this has not been done recently.
 * No non exhaustive list of changes:
 *  - T with the primitive type and
 *  - public with public static
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class ArrayPrinterDouble {


	public static void array1dToCsvFile(double[] array, String fileStr){
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(fileStr));
			for (double element : array) {
				br.write(Double.toString(element));
				br.write("\n");
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}



	public static void array2dToCsvFile(double[][] array, String fileStr){
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(fileStr));
			for (int i = 0; i<array.length; i++) {
				for (int j = 0; j<array[i].length; j++) {
					br.write(Double.toString(array[i][j]));
					if (j==array[i].length-1) {
						br.write("\n");
					} else {
						br.write(",");	
					}						
				}
			}			
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void array3dToCsvFile(double[][][] array, String fileStr){
		try {
			BufferedWriter br = new BufferedWriter(new FileWriter(fileStr));
			for (int i = 0; i<array.length; i++) {
				// Important that k and j are in this order
				for (int k = 0; k<array[0][0].length; k++) {
					for (int j = 0; j<array[0].length; j++) {
						br.write(Double.toString(array[i][j][k]));
						br.write(",");	
						if (j==array[0].length-1) {
							br.write("\n");
						} else {
							br.write(",");	
						}
					}		
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static String array1dToStr(double[] array){
		StringBuilder sb = new StringBuilder();
		for (double element : array) {
			sb.append(element);
			sb.append("\n");
		}
		return sb.toString();
	}

	public static String array2dToStr(double[][] array){
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i<array.length; i++) {
			for (int j = 0; j<array[i].length; j++) {
				sb.append(array[i][j]);
				if (j==array[i].length-1) {
					sb.append("\n");
				} else {
					sb.append(",");	
				}						
			}
		}
		return sb.toString();
	}






}
