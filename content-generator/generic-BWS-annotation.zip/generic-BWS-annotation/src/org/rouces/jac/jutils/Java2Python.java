package org.rouces.jac.jutils;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Java2Python {

	
	
	public static <T> String collection2list(Collection<T> c) {
		StringBuilder sb = new StringBuilder("[");
		for (T e : c) {
			sb.append(object2generalRepresentation(e)+",");
		}
		sb.setCharAt(sb.length()-1, ']');
		return sb.toString();
	}
	
	
	
	
	public static String string2string(CharSequence s) {
		return "'"+s.toString()+"'";
	}
	
//	public static <T extends StringPythonable> String collection2list(T e) {
//		return e.toPythonString();
//	}


	/**
	 * For the moment only working for string keys...
	 * @param m
	 * @return
	 */
	public static <K,V> String map2dictionary(Map<K,V> m) {
		//{'jack': 4098, 'sape': 4139}
		StringBuilder sb = new StringBuilder("{");
		for (K k : m.keySet()) {
			if (k instanceof CharSequence) {
				sb.append(string2string((CharSequence)k));
			} else {
				throw new RuntimeException("Only strings allowed as keys for the moment");
			}
			sb.append(":");
			V v = m.get(k);
			sb.append(object2generalRepresentation(v)+",");
		}
		sb.setCharAt(sb.length()-1, '}');
		return sb.toString();
	}
	
	
	

	public static <T> String object2generalRepresentation(Object o) {
		if (o instanceof StringPythonable) {
			return ((StringPythonable)o).toPythonString();
		} else if (o instanceof Collection<?>) {
			return collection2list((Collection<?>)o);
		} else if (o instanceof CharSequence) {
			return string2string((CharSequence)o);
		} else {
			// Last attempt
			return o.toString();
			//throw new RuntimeException("Type not allowed: "+e.getClass());
		}
	}
		
	
	public static void main(String[] args) {
		List<Double> l = new LinkedList<>();
		l.add(1.0);
		l.add(2.0);
		l.add(3.0);
		System.out.println(Java2Python.collection2list(l));
		
		Map<String,Double> map = new HashMap<>();
		map.put("one", 1.0);
		map.put("two", 2.0);
		map.put("three", 3.0);
		System.out.println(Java2Python.map2dictionary(map));

	}
	
}


