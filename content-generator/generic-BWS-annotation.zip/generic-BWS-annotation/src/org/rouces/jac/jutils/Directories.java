package org.rouces.jac.jutils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.function.BiFunction;

public class Directories {

	protected static final String S = File.separator;
	
	public static Map<String,Location> locationName2LocationObject = new HashMap<>();

	/**
	 * Abstract location independent of machine
	 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
	 *
	 */
	public enum Location {
		Dropbox("Dropbox"), 
		NotCloud("NotCloud"), 
		ExternalDrive1("ExternalDrive1"), 
		ExternalDrive2("ExternalDrive2"), 
		NetworkDrive1("NetworkDrive1");
		
		private final String name;       
		
		private String dir = null;

	    Location(String s) {
	        name = s;
	        locationName2LocationObject.put(s, this);
	    }

	    public boolean equalsName(String otherName) {
	        return name.equals(otherName);
	    }

	    public String toString() {
	       return this.name;
	    }
	    
	    public String getDir() {
	    	if (dir==null) {
	    		initDirs();
	    	}
	    	return dir;
	    }
	    
	    public void setDir(String s) {
	    	dir = s;
	    }
	}
	
	/**
	 * The most common one
	 */
	public final static Location DEFAULT_LOCATION = Location.Dropbox;
	
	/**
	 * @param location
	 * @return
	 */
	public static String getDataDir(Location location) {
		if (location==null) {
			location = DEFAULT_LOCATION; //this doesnt work??
			location = Location.Dropbox;
		}
		//System.out.println(DEFAULT_LOCATION);
		return location.getDir();
	}

	/**
	 * @param location
	 * @return
	 */
	public static String getTempDataDir(Location location) {
		return getDataDir(location)+"temp"+File.separator;
	}
	
	public static void initDirs() {
		Properties prop = new Properties();
		InputStream input = null;

		try {

			System.out.println("Reading "+System.getProperty("user.home")+S+"dataDirectories.properties");
			input = new FileInputStream(System.getProperty("user.home")+S+"dataDirectories.properties");

			// load a properties file
			prop.load(input);

			for (String propertyName : prop.stringPropertyNames()) {
				locationName2LocationObject.get(propertyName).setDir(prop.getProperty(propertyName));
				//System.out.println(propertyName);
			}

		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}
	
	public static void main(String[] args) {
		System.out.println(getDataDir(null));
	}
	
	
	
	//public static Map<Machine,Map<Location,String>> machine2location2rootMap;
	
//	public static BiFunction<Machine,Location,String> machineAndlocation2rootFunction = (Machine machine, Location location) -> {
//		
//		location.nam
//		
//		switch (machine) {
//		case MacWorkstation :
//			switch (location) {
//				case Dropbox : return "/home/jacobo/Dropbox/work/data/";
//				case NotCloud : return "/home/jacobo/Outbox/work/data/";
//				case ExternalDrive1 : return "/Volumes/WORK_ONE_TB/work/data/";
//				case ExternalDrive2 : return "/Volumes/WORK_TWO_TB_HFS/work/data/";
//				case NetworkDrive1 : return "/Volumes/jrg/data"; // from mac: smb://es-fs1.aau.dk/users/jrg/
//			}
//		case WinWorkstation :
//			switch (location) {
//				case Dropbox : return "C:\\Users\\Jacobo\\Dropbox\\work\\data\\";
//				case NotCloud : return "C:\\Users\\Jacobo\\Outbox\\work\\data\\";
//				case ExternalDrive1 : return "undefined"; 
//				case ExternalDrive2 : break;
//				case NetworkDrive1 : return "undefined";
//			}
//		case LinuxWorkstation :
//			switch (location) {
//				case Dropbox : return "/users/jacobo/Dropbox/work/data";
//				case NotCloud : return "/users/jacobo/Outbox/work/data";
//				case ExternalDrive1 : return "undefined"; 
//				case ExternalDrive2 : break;
//				case NetworkDrive1 : return "undefined";
//			}
//		case Cust2WinServer :
//			switch (location) {
//				case Dropbox : return "E:\\Dropbox\\WORK\\DATA\\";
//				case NotCloud : return "E:\\Data\\";
//				case ExternalDrive1 : return "\\\\tsclient\\WORK_TWO_TB_HFS\\WORK\\data\\"; //Cust2WinServerExtDrive2TB
//				case ExternalDrive2 : break;
//				case NetworkDrive1 : return "U:\\data\\"; // from win: smb://es.aau.dk/users/jrg/
//			}
//		}
//		throw new RuntimeException("Root directory for "+machine+" and "+location+" not defined.");
//	};
//	
//	static {
//		// Heuristics for determining machine
//		if (System.getProperty("os.name").equals("Mac OS X")) {
//			thisMachine = Machine.MacWorkstation;
//		} else {
//			thisMachine = Machine.WinWorkstation;
//		}
//	}
}
