package org.rouces.jac.jutils.onto;

/**
 * POJO for ontological class
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
@Deprecated
public class Class extends Entity {

	protected Class domain, range;

	protected Class() {
	}

	public Class(String id) {
		super(id);
	}

	public Class(String id, String name) {
		super(id, name);
	}

	public Class(String id, String name, String description) {
		super(id, name, description);
	}

}
