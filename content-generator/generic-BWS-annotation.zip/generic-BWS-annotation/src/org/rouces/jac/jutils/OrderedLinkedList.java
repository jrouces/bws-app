package org.rouces.jac.jutils;

import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedList;

/**
 * O(n) for insertion, not very efficient, only optimal for short lengths.
 * 
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 * @param <T>
 */
public class OrderedLinkedList<T> {

	public LinkedList<T> list;
	private Comparator<T> comparator;
	private int maxSize = Integer.MAX_VALUE;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3526762353718419530L;

	public OrderedLinkedList() {
		list = new LinkedList<T>();
	}

	public OrderedLinkedList(Collection<T> c) {
		list = new LinkedList<T>(c);
	}
	
	/**
	 * 
	 * 
	 * @param comparator
	 */
	public void setComparator(Comparator<T> comparator) {
		this.comparator = comparator;
	}

	
	public void addInOrder(T element) {
		if ((!list.isEmpty())&&(comparator.compare(list.getLast(),element)>0)&&(list.size()>this.maxSize)) { 
			//The element would be placed beyond maxSize, so we skip
			return;
		}
		for (int i = 0; i < list.size(); i++) {
				if (comparator.compare(list.get(i),element)<0) {
					list.add(i, element);
					if (list.size()>this.maxSize) {
						list.removeLast();
					}
					return;
				}
		}
		// For either the case that the list was empty, or that all elements were bigger
		list.add(element);
		if (list.size()>this.maxSize) {
			list.removeLast();
		}
	}

	public int getMaxSize() {
		return maxSize;
	}

	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}

}
