package org.rouces.jac.jutils.textfiles;

public interface TextFileReaderInterface {

	public String readLine();
	
	public void close();
	
}
