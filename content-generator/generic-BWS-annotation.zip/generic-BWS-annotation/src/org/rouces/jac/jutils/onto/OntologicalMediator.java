package org.rouces.jac.jutils.onto;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;

import org.rouces.jac.jutils.datastructures.Trie;

/**
 * TODO This may be made more efficient introducing explicitly a https://en.wikipedia.org/wiki/Trie , or a collection?
 * 
 * @author Jacobo Rouces <jacobo@rouces.org>
 *
 */
public class OntologicalMediator {
	
	private Map<String,Set<String>> ontologyIdToInternalNamesOfItsEntities;
	//private Trie trie;
	
	private Map<String,Map<String,String>> ontologyIdTo_EntityInternalNameToEntityExternalName;
	private Map<String,Map<String,String>> ontologyIdTo_EntityExternalNameToEntityInternalName;

	
	public OntologicalMediator() {
		// "" is the finest ontology. Would be the leaves in the trie. Actually not really needed for the moment.
		//ontologyIdToOntologyEntities.put("", new HashSet<String>());
	}
	
	public void addEntityFromOntology(String entityInternalName, String ontologyName, String entityExternalName) {
		if (ontologyIdToInternalNamesOfItsEntities.get(ontologyName)==null)
			ontologyIdToInternalNamesOfItsEntities.put(ontologyName, new HashSet<String>());
		ontologyIdToInternalNamesOfItsEntities.get(ontologyName).add(entityInternalName);
		if (ontologyIdTo_EntityInternalNameToEntityExternalName.get(ontologyName)==null)
			ontologyIdTo_EntityInternalNameToEntityExternalName.put(ontologyName, new HashMap<String,String>());
		ontologyIdTo_EntityInternalNameToEntityExternalName.get(ontologyName).put(entityInternalName,entityExternalName);
		if (ontologyIdTo_EntityExternalNameToEntityInternalName.get(ontologyName)==null)
			ontologyIdTo_EntityExternalNameToEntityInternalName.put(ontologyName, new HashMap<String,String>());
		ontologyIdTo_EntityExternalNameToEntityInternalName.get(ontologyName).put(entityExternalName,entityInternalName);
	}

	/**
	 * Uses internal ids
	 * @param targetOntology
	 * @param sourceEntity
	 * @return
	 */
	private Set<String> getMostGeneralSubentities_internalIds(String targetOntology, String sourceEntity) {
		Set<String> returnSet = new HashSet<String>();
		Set<String> targetEntities = ontologyIdToInternalNamesOfItsEntities.get(targetOntology);
		for (String targetEntity : targetEntities) {
			if (targetEntity.equals(sourceEntity)) {
				Set<String> perfectMatchSingleton = new HashSet<String>();
				perfectMatchSingleton.add(targetEntity);
				return perfectMatchSingleton;
			}
			if (targetEntity.startsWith(sourceEntity)) {
				for (String returnSetElement : returnSet) {
					if (targetEntity.startsWith(returnSetElement)) {
						continue;
					}
					// Here we have checked there isn't another subentity that is more general
					returnSet.add(targetEntity);
				}
			}
		}
		return returnSet;
	}
	
	/**
	 * Uses internal ids
	 * @param targetOntology
	 * @param sourceEntity
	 * @return
	 */
	private String getMostSpecificSuperentity_internalIds(String targetOntology, String sourceEntity) {
		PriorityQueue<String> returnSet = new PriorityQueue<String>(10,Collections.reverseOrder());
		Set<String> targetEntities = ontologyIdToInternalNamesOfItsEntities.get(targetOntology);
		for (String targetEntity : targetEntities) {
			if (targetEntity.equals(sourceEntity)) {
				return targetEntity;
			}
			if (sourceEntity.startsWith(targetEntity)) {
				returnSet.add(targetEntity);
			}
		}
		
		return returnSet.poll();
	}
	
	/**
	 * Uses internal ids
	 * @param targetOntology
	 * @param sourceEntity
	 * @return
	 */
	private boolean hasPerfectMatch_internalIds(String targetOntology, String sourceEntity) {
		Set<String> targetEntities = ontologyIdToInternalNamesOfItsEntities.get(targetOntology);
		return targetEntities.contains(sourceEntity);
	}

	
	/**
	 * @param targetOntology
	 * @param sourceEntity
	 * @return
	 */
	public Set<String> getMostGeneralSubentities(String targetOntology, String sourceEntity) {
		Set<String> returnSet = new HashSet<String>();
		Set<String> internalIds = getMostGeneralSubentities_internalIds(
				targetOntology,
				ontologyIdTo_EntityExternalNameToEntityInternalName.get(targetOntology).get(sourceEntity));
		internalIds.stream().forEach((String s) -> returnSet.add(ontologyIdTo_EntityInternalNameToEntityExternalName.get(targetOntology).get(s)));
		return returnSet;
	}
	
	/**
	 * @param targetOntology
	 * @param sourceEntity
	 * @return
	 */
	public String getMostSpecificSuperentity(String targetOntology, String sourceEntity) {
		String s = getMostSpecificSuperentity_internalIds(
				targetOntology,
				ontologyIdTo_EntityExternalNameToEntityInternalName.get(targetOntology).get(sourceEntity));
		return s==null?null:ontologyIdTo_EntityInternalNameToEntityExternalName.get(targetOntology).get(s);
	}
	
	/**
	 * @param targetOntology
	 * @param sourceEntity
	 * @return
	 */
	public boolean hasPerfectMatch(String targetOntology, String sourceEntity) {
		return hasPerfectMatch_internalIds(
				targetOntology,
				ontologyIdTo_EntityExternalNameToEntityInternalName.get(targetOntology).get(sourceEntity));
	}
}

/**
 * TODO move out
 * @author Jacobo Rouces <jacobo@rouces.org>
 *
 */
class PosMediator {
	
	public static OntologicalMediator s = new OntologicalMediator();
	
	public static void main(String[] args) {
		s.addEntityFromOntology("noun", "pwn", "n");
		s.addEntityFromOntology("verb", "pwn", "v");
		s.addEntityFromOntology("adjective", "pwn", "a");
		s.addEntityFromOntology("adjective-satellite", "pwn", "s");
		s.addEntityFromOntology("adverb", "pwn", "r");
		
	}
	
	
}


