package org.rouces.jac.jutils;

import java.io.File;
import java.util.Map;
import java.util.function.BiFunction;

public class DirectoriesOldVersion {

	protected static final String S = File.separator;
	
	public enum Machine {
		MacWorkstation, 
		WinWorkstation, 
		LinuxWorkstation,
		Cust2WinServer
	}
	
	public static Machine thisMachine;
	
	/**
	 * Abstract location independent of machine
	 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
	 *
	 */
	public enum Location {
		Dropbox, 
		NotCloud,
		ExternalDrive1,
		ExternalDrive2,
		NetworkDrive1
	}
	
	/**
	 * The most common one
	 */
	public final static Location DEFAULT_LOCATION = Location.Dropbox;

	
	//public static Map<Machine,Map<Location,String>> machine2location2rootMap;
	
	public static BiFunction<Machine,Location,String> machineAndlocation2rootFunction = (Machine machine, Location location) -> {
		
		switch (machine) {
		case MacWorkstation :
			switch (location) {
				case Dropbox : return "/home/jacobo/Dropbox/work/data/";
				case NotCloud : return "/home/jacobo/Outbox/work/data/";
				case ExternalDrive1 : return "/Volumes/WORK_ONE_TB/work/data/";
				case ExternalDrive2 : return "/Volumes/WORK_TWO_TB_HFS/work/data/";
				case NetworkDrive1 : return "/Volumes/jrg/data"; // from mac: smb://es-fs1.aau.dk/users/jrg/
			}
		case WinWorkstation :
			switch (location) {
				case Dropbox : return "C:\\Users\\Jacobo\\Dropbox\\work\\data\\";
				case NotCloud : return "C:\\Users\\Jacobo\\Outbox\\work\\data\\";
				case ExternalDrive1 : return "undefined"; 
				case ExternalDrive2 : break;
				case NetworkDrive1 : return "undefined";
			}
		case LinuxWorkstation :
			switch (location) {
				case Dropbox : return "/users/jacobo/Dropbox/work/data";
				case NotCloud : return "/users/jacobo/Outbox/work/data";
				case ExternalDrive1 : return "undefined"; 
				case ExternalDrive2 : break;
				case NetworkDrive1 : return "undefined";
			}
		case Cust2WinServer :
			switch (location) {
				case Dropbox : return "E:\\Dropbox\\WORK\\DATA\\";
				case NotCloud : return "E:\\Data\\";
				case ExternalDrive1 : return "\\\\tsclient\\WORK_TWO_TB_HFS\\WORK\\data\\"; //Cust2WinServerExtDrive2TB
				case ExternalDrive2 : break;
				case NetworkDrive1 : return "U:\\data\\"; // from win: smb://es.aau.dk/users/jrg/
			}
		}
		throw new RuntimeException("Root directory for "+machine+" and "+location+" not defined.");
	};
	
	static {
		// Heuristics for determining machine
		if (System.getProperty("os.name").equals("Mac OS X")) {
			thisMachine = Machine.MacWorkstation;
		} else {
			thisMachine = Machine.WinWorkstation;
		}
	}
	
	/**
	 * @param location
	 * @return
	 */
	public static String getDataDir(Location location) {
		if (location==null) {
			return machineAndlocation2rootFunction.apply(thisMachine, DEFAULT_LOCATION);
		} else {
			return machineAndlocation2rootFunction.apply(thisMachine, location);
		}
	}

	/**
	 * @param location
	 * @return
	 */
	public static String getTempDataDir(Location location) {
		return getDataDir(location)+"temp"+File.separator;
	}
}
