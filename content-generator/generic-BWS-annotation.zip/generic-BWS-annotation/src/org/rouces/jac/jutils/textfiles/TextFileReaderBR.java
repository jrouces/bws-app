package org.rouces.jac.jutils.textfiles;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import org.rouces.jac.jutils.system.SystemAlt;

/**
 * Reads using a buffered reader.
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class TextFileReaderBR implements TextFileReaderInterface {

	private BufferedReader bufferedReader;
	
	public TextFileReaderBR(String fileName) {
		try {
			InputStream fileStream = new FileInputStream(fileName);
			Reader reader = new InputStreamReader(fileStream, "UTF-8");
			bufferedReader = new BufferedReader(reader);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String readLine() {
		try {
			return bufferedReader.readLine();
		} catch (IOException e) {
			e.printStackTrace();
			SystemAlt.exit();
			return null;
		}
	}
	
	public void close() {
		try {
			bufferedReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Gets number of lines using the same implementation method.
	 * @param fileStr
	 * @return
	 */
	public static int getNumberOfLines(String fileStr) {
		int numberOfLines = 0;
		TextFileReaderBR reader = new TextFileReaderBR(fileStr);
		while ((reader.readLine()) != null) {
			numberOfLines++;
		}
		return numberOfLines;
	}
	
}
