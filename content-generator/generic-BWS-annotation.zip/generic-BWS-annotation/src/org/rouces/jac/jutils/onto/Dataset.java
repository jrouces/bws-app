package org.rouces.jac.jutils.onto;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Incomplete
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class Dataset {

	// Indices of entity ids
	private Map<String,Map<String,Set<String>>> spo, sop, pso, pos, osp, ops;
	
	// Id to entity map
	private Map<String,Entity> id2entity;
	
	// Entity set, serves as entity2id implicitly
	// id2entity.values() already provides this
	// private Set<Entity> entities;
	
	// Triple set, serves as entity2id implicitly
	private Set<Triple> triples;
	
	public Dataset() {
		spo = new HashMap<String,Map<String,Set<String>>>();
		sop = new HashMap<String,Map<String,Set<String>>>();
		pso = new HashMap<String,Map<String,Set<String>>>();
		pos = new HashMap<String,Map<String,Set<String>>>();
		osp = new HashMap<String,Map<String,Set<String>>>();
		ops = new HashMap<String,Map<String,Set<String>>>();
		id2entity = new HashMap<String,Entity>();
		triples = new HashSet<Triple>();
	}

	public void addTriple(Triple newTriple) {
		Map<String,Set<String>> s_po = spo.get(newTriple.getSubject().getId());
		if (s_po!=null) {
			Set<String> sp_o = s_po.get(newTriple.getPredicate());
			if (sp_o!=null) {
				if (sp_o.contains(newTriple.getObject())) {
					// Then newTriple is already in the dataset
				} else {
					// sp_o exists but has no o
					sp_o.add(newTriple.getObject().getId());
					id2entity.put(newTriple.getObject().getId(), newTriple.getObject());
					triples.add(newTriple);
				}
			} else {
				// s_po exists but has no sp_o, which must be created.
				sp_o = new HashSet<String>();
				sp_o.add(newTriple.getObject().getId());
				s_po.put(newTriple.getPredicate().getId(),sp_o);
				id2entity.put(newTriple.getObject().getId(), newTriple.getObject());
				triples.add(newTriple);			
			}
		} else {
			// spo (always) exists but has no s_po, which must be created; but this has no sp_o, which must be created.
			Set<String> sp_o = new HashSet<String>();
			sp_o.add(newTriple.getObject().getId());
			s_po = new HashMap<String,Set<String>>();
			s_po.put(newTriple.getPredicate().getId(),sp_o);
			spo.put(newTriple.getSubject().getId(), s_po);
			id2entity.put(newTriple.getObject().getId(), newTriple.getObject());
			triples.add(newTriple);			
		}
		//TODO other indices, moving to static method perhaps?
	}
	
	public void removeTriple() {
		//TODO
	}
	
	public Stream getTripleStream() {
		return triples.stream();
	}
	
}
