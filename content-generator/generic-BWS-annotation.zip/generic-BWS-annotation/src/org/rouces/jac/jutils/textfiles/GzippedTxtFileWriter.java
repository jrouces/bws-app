package org.rouces.jac.jutils.textfiles;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.zip.GZIPOutputStream;

public class GzippedTxtFileWriter implements TextFileWriterInterface {
	
	private File file;
	private Writer writer;
	
	public GzippedTxtFileWriter(String fileName) {
		try {
			file = new File(fileName);
			if(!file.exists()) {
				file.getParentFile().mkdirs();
				file.createNewFile();
			}
			FileOutputStream fileOutputStream = new FileOutputStream(file);
			writer = new OutputStreamWriter(new GZIPOutputStream(fileOutputStream), "UTF-8");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	/**
	 * Prints and flushes
	 * @param string
	 */
	public void println(String string) {
		try {
			writer.write(string+"\n");
			//writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Prints and flushes
	 * @param string
	 */
	public void print(String string) {
		try {
			writer.write(string);
			//writer.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * This should be automated with some kind of "last method".
	 */
	public void close() {
		try {
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
