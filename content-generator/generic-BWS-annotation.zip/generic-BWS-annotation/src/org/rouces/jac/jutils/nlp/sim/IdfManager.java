package org.rouces.jac.jutils.nlp.sim;

import org.rouces.jac.jutils.datastructures.SparseVector;

/**
 * Manages the creation of a vector with Inverse Document Frequency Indices
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 */
public class IdfManager {

	private int numberOfDocuments;
	private SparseVector<String> dfVector;
	
	public IdfManager() {
		numberOfDocuments = 0;
		dfVector = new SparseVector<String>();
	}

	public void addDocument(SparseVector<String> newDocument) {
		numberOfDocuments++;
		dfVector.addOtherVector(new SparseVector<String>(newDocument.getMap().keySet()));
		//System.out.println(dfVector.toString());
	}
	
	public SparseVector<String> getIdfVector() {
		SparseVector<String> idfVector = new SparseVector<String>();
		for (String element : dfVector.getMap().keySet()) {
			idfVector.putElementWithValue(element, Math.log(numberOfDocuments/dfVector.getElementValue(element)));
//			System.out.println(numberOfDocuments);
//			System.out.println(dfVector.getElementValue(element));
//			System.out.println(numberOfDocuments/dfVector.getElementValue(element));
//			System.out.println(Math.log(numberOfDocuments/dfVector.getElementValue(element)));
		}
		return idfVector;
	}
	
}
