package org.rouces.jac.jutils.snippets;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.rouces.jac.jutils.Directories;
import org.rouces.jac.jutils.datastructures.SparseVector;
import org.rouces.jac.jutils.textfiles.TextFileReaderBR;

public class CsvFileReader {

	public static void load() {
		
		Set<String> set = new HashSet<>();
		Map<String,String> map = new HashMap<>();
		
		Path file = Paths.get(Directories.getDataDir(null), "dir/gigaword","file.txt");
		
		TextFileReaderBR reader = new TextFileReaderBR(file.toString());
		String line = reader.readLine();
		int linesRead = 0;
		while((line = reader.readLine())!=null) {
			linesRead++;
			if (line.startsWith("#")||line.isEmpty()) {
				line = reader.readLine();
				continue;
			}
			// Using split
			String[] elements = line.split("\\t");
			String el0 = elements[0];
			String el1 = elements[1];
			String el2 = elements[2];
			// Using regex
			final Pattern p = Pattern.compile("(.*)\\t(.*)");
			Matcher m = p.matcher(line);
			String g1 = m.group(1);
			String g2 = m.group(2);
			String g3 = m.group(3);
			
			// ...
		}
		System.out.println("linesRead="+linesRead);
	}

}
