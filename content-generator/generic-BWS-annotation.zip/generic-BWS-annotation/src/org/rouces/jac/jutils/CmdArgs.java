package org.rouces.jac.jutils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/* 
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 *
 */

/**
 * 
 * A representation of the command line arguments passed to a
 * Java class' main(String[]) method. It parses the arguments for flags (tokens
 * prefixed with a dash ('-')), flag-value pairs, and an ordered list of
 * argument values.
 * 
 * @author Dan Jemiolo (danj)
 * Modified by @author Jacobo Rouces (jrouces@gmail.com)
 * 
 */

public class CmdArgs {

	// all non-flag values
	private String[] nonFlagArguments = null;

	// the flags (-foo) that were found on the command line
	private Map<String,String> flags = new HashMap<String,String>();

	// the flag values that are expected to be followed with a value 
	// that allows the application to process the flag.
	private Set<String> flagsWithValues = new HashSet<String>();

	/**
	 * 
	 * @return All of the values specified on the command line that were not a
	 *         flag or associated with a flag.
	 * 
	 */
	public String[] getNonFlagArguments() {
		return nonFlagArguments;
	}

	/**
	 * 
	 * @param flagName
	 * 
	 * @return The value that was specified after the flag, or null if the flag or the value
	 *         was not specified.
	 * 
	 * @see #hasFlag(String)
	 * 
	 */
	public String getFlagValue(String flagName) {
		return (String) flags.get(flagName);
	}

	public int getNumberOfArguments() {
		return nonFlagArguments.length;
	}

	public int getNumberOfFlags() {
		return flags.size();
	}

	/**
	 * 
	 * @param flagName
	 * 
	 * @return True if the flag was specified on the command line.
	 * 
	 */
	public boolean hasFlag(String flagName) {
		return flags.containsKey(flagName);
	}

	/**
	 * 
	 * Reads through each argument in the given array, picking out the flags
	 * (and optionally,their values) from the regular arguments. Users should
	 * use the saveFlagValue(String) method before this one in order to have
	 * their command line parsed correctly.
	 * 
	 * @param args
	 *            The command line arguments given to the application.
	 * 
	 */
	public void parse(String[] args) {
		try{
			List<String> regularArgs = new ArrayList<String>();
			for (int n = 0; n < args.length; ++n) {
				if (args[n].charAt(0) == '-') {
					String name = args[n];
					String value = null;
					if (flagsWithValues.contains(args[n]) && n < args.length - 1)
						value = args[++n];
					flags.put(name, value);
				}
				else
					regularArgs.add(args[n]);
			}
			nonFlagArguments = (String[]) regularArgs.toArray(new String[regularArgs.size()]);
		} catch (Exception e) {
			System.err.println("Invalid arguments");
			System.exit(1);
		}
	}

	/**
	 * 
	 * Tells the command line parser to associate the given flag with the value
	 * that comes after it in the list of arguments (if the flag is found). This
	 * will allow the user to retrieve the flag-value pair later and prevent the
	 * flag value from being lumped in with the regular arguments.
	 * 
	 * @param flagName
	 * 
	 */
	public void saveFlagValue(String flagName) {
		flagsWithValues.add(flagName);
	}
}
