package org.rouces.jac.jutils.datastructures.relations;

import java.util.Set;

/**
 * Models a mathematical relation wrapping as a set of pairs and provides methods to use it as a function when possible.
 * Remember A and B must re-implement equals and hash methods properly!
 * @author Jacobo Rouces {@literal <jacobo@rouces.org>}
 *
 * @param <A>
 * @param <B>
 */
@Deprecated
public interface RelationWithPrecomputedMapsInterface<A, B> {

	public abstract void addPair(A a, B b);

	public abstract boolean existsPair(A a, B b);

	/**
	 * Returns null if none.
	 */
	public abstract B getForwardFunctionalElement(A a);

	/**
	 * Returns null if none.
	 * @param b
	 * @return
	 */
	public abstract A getBackwardFunctionalElement(B b);

	/**
	 * Returns an empty set if none
	 */
	public abstract Set<B> getForwardNaryElements(A a);

	/**
	 * Returns an empty set if none
	 * @param b
	 * @return
	 */
	public abstract Set<A> getBackwardNaryElements(B b);

}