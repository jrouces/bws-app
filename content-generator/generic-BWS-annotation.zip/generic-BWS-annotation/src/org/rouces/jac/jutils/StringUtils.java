package org.rouces.jac.jutils;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class StringUtils {

	final private static char[] hexArray = "0123456789ABCDEF".toCharArray();

	public static void main(String[] args) {
		System.out.println(StringUtils.fromCamelCase("helloMortadeloYFilemon2"));
		System.out.println(StringUtils.fromCamelCase("HelloMortadeloYFilemon2"));
		System.out.println(StringUtils.fromCamelCase("Hello-mortadelo_y_Filemon2"));;


	}
	
	/**
	 * Converts strings separated by spaces or underscores into CamelCase.
	 * It also applies transformation to safe characters, so it may lose information
	 * @param in
	 * @param firstIsOmitted
	 * @return
	 */
	public static String toCamelCase(String in, boolean firstIsOmitted) {
		in.replaceAll("[^_\\sa-zA-Z0-9]", "");
		String[] chunks = in.split("[_\\s]+");
		StringBuilder sb = new StringBuilder();
		for (int i=0;i<chunks.length;i++) {
			String chunk = chunks[i];
			if (firstIsOmitted&&(i==0)) {
				sb.append(chunk.toLowerCase());
			} else {
				sb.append(chunk.substring(0, 1).toUpperCase() + chunk.substring(1).toLowerCase());
			
			}
		}
		return sb.toString();
	}
	
	/**
	 * Converts CamelCased or camelCased strings to strings separated with spaces, all lowercase.
	 * Use this only as a fall-back option if no labels are available!!
	 * Not necessarily inverse of toCamelCase()
	 * @param in
	 * @return
	 */
	public static String fromCamelCase(String in) {
		String out = in.replaceAll("(?=[A-Z])", " ").toLowerCase().replaceAll("[^a-z]+", " ").trim();
		return out;
	}
	
	/**
	 * Removes apostrophes and anything that is not [a-zA-Z0-9]
	 * @param in
	 * @return
	 */
	public static String toSimpleUrlPath(String in) {
		String out = in.replaceAll("(?=[A-Z])", " ");
		return out;
	}
	
	/**
	 * Converts string into something accepted as filename, leaving only allowed characters, but trying to preserve readability. 
	 * Does not include the dots!!
	 * It does not ensure there will be no collisions!!
	 * @param in
	 * @return
	 */
	public static String toValidFileName(String in) {
		return in.replaceAll("\\W+", "");
	}
	
	/**
	 * Converts string into something accepted as filename, leaving only allowed characters, but trying to preserve readability. 
	 * Does not include the dots!!
	 * It ensures no collisions!!
	 * @param in
	 * @return
	 */
	public static String toValidFileNameWoCollisions(String in) {
		return getMd5Hash(in)+"-"+in.replaceAll("\\W+", "_");
	}


	public static String bytesToHex(byte[] bytes) {
	    char[] hexChars = new char[bytes.length * 2];
	    for ( int j = 0; j < bytes.length; j++ ) {
	        int v = bytes[j] & 0xFF;
	        hexChars[j * 2] = hexArray[v >>> 4];
	        hexChars[j * 2 + 1] = hexArray[v & 0x0F];
	    }
	    return new String(hexChars);
	}

	
	/**
	 * The result is 32 characters long
	 * 
	 * @param input
	 * @return
	 */
	@Deprecated
	public static String getMd5Hash(String input) {
		return getHash(input, "MD5");
	}
	
	/**
	 * Encodings:
	 * MD5     32 char length
	 * SHA-1   40 char length
	 * 
	 * @param input
	 * @return
	 */
	public static String getHash(String input, String encoding) {
		byte[] bytesOfMessage;
		try {
			bytesOfMessage = input.getBytes("UTF-8");
			MessageDigest md = MessageDigest.getInstance(encoding);
			byte[] thedigest = md.digest(bytesOfMessage);
			return bytesToHex(thedigest);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		return null;
	}

	
}
