package org.rouces.jac.jutils.textfiles;

public interface TextFileWriterInterface {

	public enum Mode {APPEND, ERASE}

	/**
	 * Prints and flushes
	 * @param string
	 */
	public  void println(String string);
	
	/**
	 * Prints and flushes
	 * @param string
	 */
	public void print(String string);
	
	/**
	 * This should be automated with some kind of "last method".
	 */
	public void close();
	
	
}
