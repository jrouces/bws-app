
package org.tartarus.snowball;

public abstract class SnowballStemmer extends SnowballProgram {
    public abstract boolean stem();
};
