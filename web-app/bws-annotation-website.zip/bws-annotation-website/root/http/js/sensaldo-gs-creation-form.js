

//document.getElementById("demo").innerHTML = "My First JavaScript";

//$(document).ready(function(){
 
    //$("body").html("jQuery is working");  
 
  //});


function swapSelection(id,autoscroll) {
  
  console.log("entering function for swapping selection "+id)
  if (typeof(autoscroll)==='undefined') autoscroll = true;
  //node = document.getElementById(id);
  clickedNode = $("#"+id.replace("..","\\.\\."))
  if (clickedNode.hasClass("selected")) {
    clickedNode.removeClass("selected")
    updateGroupStatus(clickedNode)
  } else {
    // If there is another element of the same group already selected, pass
    for (var i = 0; i < clickedNode.prop("classList").length; i++) {
      className = clickedNode.prop("classList")[i]
      if (className.startsWith("group-")) {
        otherNodesInGroup = $("."+className.replace("..","\\.\\."));
        for (i2 = 0; i2 < otherNodesInGroup.length; i2++) {
        //$("."+className.replace("..","\\.\\.")).each(function() {
          //console.log(this)
          //if ($(this).hasClass("selected")) {
          if (otherNodesInGroup.eq(i2).hasClass("selected")) {
            //console.log("nope");
            return;
          }
        }//);
      }
    }
    
    // If the unknown button was already selected, pass
    if (clickedNode.closest(".group-table").find(".unknown-selector").hasClass("selected")) {
    //if (document.getElementById(id).className.endsWith(" selected")) {
      console.log("the unknown button was already selected")
      return;
    }
    // If this is the unknown button and any other button was already selected, pass
    if (clickedNode.hasClass("unknown-selector")&&clickedNode.closest(".group-table").find("td").hasClass("selected")) {
    	console.log("the unknown button and any other button was already selected")
    	return;
    }
    // At this point we know there is not another element of the same group already selected
    clickedNode.addClass("selected")
    updateGroupStatus(clickedNode,autoscroll)
    //debugger;


  }
}

function updateGroupStatus(clickedNode,autoscroll) {
    // check if the group is now filled, if so add filled class and move on
    thisGroup = clickedNode.closest(".group-table");
    if (
      thisGroup.find(".unknown-selector.selected").length>0 ||
      ((thisGroup.find(".positive-selector.selected").length>0)&&(thisGroup.find(".negative-selector.selected").length>0))
      ) {
      //console.log("this group is filled")
      thisGroup.addClass("filled")
      if (autoscroll) {
        nextGroup = thisGroup.next().next().next().next(); //mecause there are 3 <br>s in the middle
        moveFocusToGroup(nextGroup)
      }
      $("#"+thisGroup.attr('id').replace("..","\\.\\.")+"-link").addClass("omitted")
    } else {
      thisGroup.removeClass("filled")
      $("#"+thisGroup.attr('id').replace("..","\\.\\.")+"-link").removeClass("omitted")

    }
}

// Scroll
// ================

function moveFocusToGroup(targetGroup) {
      // the next line is required to work around a bug in WebKit (Chrome / Safari)
      //debugger;
      //location.href = "#";
      //location.href = "#"+nextGroup.attr('id');
      //location.href = "#"+thisGroup.attr('id');
      
      //targetGroup.prev().prev().prev().prev().scrollView(); //this in theory
      //targetGroup.prev().prev().prev().prev().prev().prev().prev().prev().scrollView(); //hack
      targetGroup.scrollView(); //hack
      targetGroup.addClass('highlighted'); setTimeout(function(){targetGroup.removeClass('highlighted');}, 2000);
}



$.fn.scrollView = function () {
  //"this[0]" here is the element table#group-table-9
  //391 is the vertical space between the scrollable div and the top of the page
  //to obtain this value after css changes, run console.log(this.offset().top) with the scroll bar at the top
  $('#groups-auto').animate({
      scrollTop: (this.offset().top-391-($("#group-table-0").offset().top-391))
      //scrollTop: jrg
  }, 500);
}



// Code gen & parse
// ================

function generateCode() {
  document.getElementById('code-textarea').value = ""
  $(".group-table").each(function() {
      $(this).find(".selected").each(function() {
          console.log($(this).attr('id'));
          document.getElementById('code-textarea').value += $(this).attr('id')+"\n"
      });
  });
  document.getElementById('code-textarea').select();
}



function useCode() {
  console.log(document.getElementById('code-textarea').value);
  console.log(document.getElementById('code-textarea').value.split("\n"));
  try {
    selectedElementIds = document.getElementById('code-textarea').value.split("\n")
    selectedElementIds.forEach(function(item) {
      if (item.length>0) {
        swapSelection(item,false)
      }
    });
  } catch (e) {
     alert("Syntax error in the loaded file!! The file may have been modified or corrupted.\nTrace:\n"+e);
  }
}

function readFile(e) {
  var file = e.target.files[0];
  if (!file) {
    return;
  }
  var reader = new FileReader();
  reader.onload = function(e) {
    var contents = e.target.result;
    document.getElementById('code-textarea').value = contents;
    useCode();
  };
  reader.readAsText(file);
}


// Init code
// =========
$(document).ready(function () {

  if (window.File && window.FileReader && window.FileList && window.Blob) {
    console.log("Great success! All the File APIs are supported.");
  } else {
    alert('The File APIs are not fully supported in this browser.');
  }
  $("#save-file-btn").click(function() {
    generateCode();
    var blob = new Blob([document.getElementById('code-textarea').value], {type: "text/plain;charset=utf-8"});
    saveAs(blob, "session.txt");
  });

  $("#load-file-btn")[0].addEventListener('change', readFile, false);

  // $(document).keydown(function(e) {
  //   switch(e.which) {
  //       case 37: // left
  //       case 38: // up
  //       moveFocusToGroup()
  //       break;

  //       case 39: // right
  //       case 40: // down
  //       moveFocusToGroup()
  //       break;

  //       default: return; // exit this handler for other keys
  //   }
  //   //e.preventDefault(); // prevent the default action (scroll / move caret)
  // });

});