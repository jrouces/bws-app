/*
 * !!! ONLY
 * !!! FUNCTION
 * !!! DEFINTIONS
 */

/**
 * Utilities module
 * @returns 
 */
JrgUtils = (function() {
	var _p = {};
	
	/**
	 * expanded json
	 */
	_p.s = function(variable) {
		return JSON.stringify(variable, null, " ");
	}

	
	_p.makeRandomAphanumericId = function(lengthInt) {
	    var text = "";
	    var possible = "abcdefghijklmnopqrstuvwxyz0123456789";
	    for( var i=0; i < lengthInt; i++ )
	        text += possible.charAt(Math.floor(Math.random() * possible.length));

	    return text;
	}
	

	_p.hasClass = function(el, className) {
		if (el.classList)
			return el.classList.contains(className)
		else
			return !!el.className.match(new RegExp('(\\s|^)' + className
					+ '(\\s|$)'))
	}

	_p.addClass = function(el, className) {
		if (el.classList)
			el.classList.add(className)
		else if (!hasClass(el, className))
			el.className += " " + className
	}

	_p.removeClass = function(el, className) {
		if (el.classList)
			el.classList.remove(className)
		else if (hasClass(el, className)) {
			var reg = new RegExp('(\\s|^)' + className + '(\\s|$)')
			el.className = el.className.replace(reg, ' ')
		}
	}
	
	return _p;
})();

/**
 * Creates array repeating value len times
 * 
 * @param value
 * @param len
 * @returns {Array}
 */
function fillArray(value, len) {
	var arr = [];
	for (var i = 0; i < len; i++) {
		arr.push(value);
	}
	return arr;
}

/**
 * The native version of this is still not widely implemented
 */
function startsWith(whole, prefix) {
	return whole.substring(0, prefix.length) == prefix;
}

/**
 * Using Double Equals (DE) (==)
 */
function arrayContainsDE(array, element) {
	//console.log("Is this bad???"+array.length+"=?"+triples.length);
	//console.log("array: "+JSON.stringify(array, null, "\t"));
	//console.log("triples: "+JSON.stringify(triples, null, "\t"));
	for (idx = 0; idx < array.length; idx++) {
		if (array[idx]==element)
			return true;
	}
	return false;
}

function changeImage(imgId, imagePath) {
	//console.log("hi");
	var img = document.getElementById(imgId);
	img.href= imagePath;
	img.src=imagePath;
}

/**
 * 
 */
function capitalizeFirstLetter(string) {
	return string.charAt(0).toUpperCase() + string.slice(1);
}


var errorHandlerFunction = function(message) {
	// alert("errorHandler!!: " + message);
	console.log("Generic errorHandler called. Message: " + message);
};

/**
 * console.log expanded json
 */
var conLogExp = function(variable) {
	console.log("textNode: "+JSON.stringify(variable, null, " "));
}

